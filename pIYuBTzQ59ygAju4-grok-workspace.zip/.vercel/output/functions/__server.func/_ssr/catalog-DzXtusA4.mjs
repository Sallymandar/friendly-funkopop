import { i as __toESM } from "../_runtime.mjs";
import { n as figures } from "./catalog-BXF-4cw1.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useShelf, d as money, f as quote, i as PageHeader, l as field, t as Badges } from "./shelf-C96d3s3d.mjs";
import { i as lenses, r as Route$5 } from "./router-aYaoQcLy.mjs";
import { t as VinylPlate } from "./vinyl-UzJl_sOE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-DzXtusA4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CatalogPage() {
	const search = Route$5.useSearch();
	const navigate = Route$5.useNavigate();
	const custom = useShelf((s) => s.custom);
	const logged = useShelf((s) => s.sales);
	const [sort, setSort] = (0, import_react.useState)("name");
	const pool = (0, import_react.useMemo)(() => [...custom, ...figures], [custom]);
	const lines = (0, import_react.useMemo)(() => [...new Set(pool.map((f) => f.series))], [pool]);
	const rows = (0, import_react.useMemo)(() => {
		const q = search.q.trim().toLowerCase();
		const list = pool.filter((f) => {
			if (search.family && f.familyId !== search.family) return false;
			if (search.series && f.series !== search.series) return false;
			if (search.lens === "chase" && !f.isChase) return false;
			if (search.lens === "exclusive" && f.exclusiveKind === "none") return false;
			if (search.lens === "vaulted" && f.production !== "Vaulted") return false;
			if (!q) return true;
			return [
				f.name,
				f.character,
				f.number,
				f.variant,
				f.license,
				f.series,
				f.sticker,
				f.retailer,
				f.convention,
				f.upc,
				f.id
			].filter(Boolean).join(" ").toLowerCase().includes(q);
		});
		list.sort((a, b) => {
			if (sort === "value") {
				const av = quote(a.sales, logged.filter((s) => s.recordId === a.id), "Mint");
				const bv = quote(b.sales, logged.filter((s) => s.recordId === b.id), "Mint");
				const ae = av.source === "logged" ? av.estimate : -1;
				return (bv.source === "logged" ? bv.estimate : -1) - ae;
			}
			if (sort === "year") return b.year - a.year;
			if (sort === "number") return a.number.localeCompare(b.number, void 0, { numeric: true });
			return a.name.localeCompare(b.name) || a.variant.localeCompare(b.variant);
		});
		return list;
	}, [
		search,
		sort,
		pool,
		logged
	]);
	const familyName = search.family ? pool.find((f) => f.familyId === search.family) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Catalog",
				title: familyName ? `${familyName.name} #${familyName.number}` : "Master catalog",
				lede: familyName ? `${rows.length} variants share this number. They stay in one family.` : "Starter ledger of known rows, plus any figure you add. Verified prices appear only after a logged sale."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/add",
				className: "self-start text-sm text-amber",
				children: "Add a missing figure"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: field,
						value: search.q,
						onChange: (e) => void navigate({
							search: {
								...search,
								q: e.target.value
							},
							replace: true
						}),
						placeholder: "Name, number, sticker, retailer",
						"aria-label": "Filter catalog"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto pb-1",
						children: ["", ...lines].map((series) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `min-h-11 shrink-0 rounded-full px-4 ${search.series === series ? "bg-amber text-amber-ink" : "border border-line text-paper"}`,
							onClick: () => void navigate({ search: {
								...search,
								series
							} }),
							children: series || "All lines"
						}, series || "all"))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [lenses.map((lens) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `min-h-11 rounded-full px-4 capitalize ${search.lens === lens ? "bg-panel-2 text-paper" : "text-mute"}`,
							onClick: () => void navigate({ search: {
								...search,
								lens
							} }),
							children: lens
						}, lens)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "ml-auto flex items-center gap-2 text-sm text-mute",
							children: ["Sort", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "min-h-11 rounded-xl border border-line bg-ink px-2 text-paper",
								value: sort,
								onChange: (e) => setSort(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "name",
										children: "Name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "number",
										children: "Number"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "year",
										children: "Year"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "value",
										children: "Estimate"
									})
								]
							})]
						})]
					}),
					search.family && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "self-start text-sm text-amber",
						onClick: () => void navigate({ search: {
							...search,
							family: ""
						} }),
						children: "Clear family filter"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mute",
				children: [rows.length, " records"]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border border-line bg-panel px-4 py-8 text-dim",
				children: "Nothing in the ledger matches that."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: rows.map((figure) => {
					const q = quote(figure.sales, logged.filter((s) => s.recordId === figure.id), "Mint");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/record/$id",
						params: { id: figure.id },
						className: "block rounded-2xl focus-visible:outline-offset-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VinylPlate, { figure }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: figure.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mute",
									children: [
										figure.series,
										" · ",
										figure.year
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl tabular-nums",
										children: q.source === "logged" ? money(q.estimate) : "—"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-mute",
										children: q.source === "logged" ? `${q.count} logged` : "Unpriced"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badges, { figure })
							})
						]
					}) }, figure.id);
				})
			})
		]
	});
}
//#endregion
export { CatalogPage as component };
