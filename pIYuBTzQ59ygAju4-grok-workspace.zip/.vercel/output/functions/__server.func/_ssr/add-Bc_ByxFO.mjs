import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useShelf, i as PageHeader, l as field, o as btnAmber } from "./shelf-C96d3s3d.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-Bc_ByxFO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var finishes = [
	"matte",
	"metallic",
	"flocked",
	"glow",
	"chrome"
];
var exclusives = [
	"none",
	"retailer",
	"convention",
	"shared"
];
var productions = [
	"Vaulted",
	"In production",
	"Retired"
];
var paint = {
	matte: {
		head: "#c4b49a",
		body: "#8a8070",
		accent: "#e4a322"
	},
	metallic: {
		head: "#d5d8df",
		body: "#9aa0a8",
		accent: "#e4a322"
	},
	flocked: {
		head: "#e6d3a1",
		body: "#c4b49a",
		accent: "#8a5a3a"
	},
	glow: {
		head: "#d8ffb0",
		body: "#7dcc6a",
		accent: "#f4fff0"
	},
	chrome: {
		head: "#e6c56b",
		body: "#c6a15a",
		accent: "#f3ead7"
	}
};
function slug(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "figure";
}
function AddPage() {
	const navigate = useNavigate();
	const addCustom = useShelf((s) => s.addCustom);
	const [name, setName] = (0, import_react.useState)("");
	const [number, setNumber] = (0, import_react.useState)("");
	const [variant, setVariant] = (0, import_react.useState)("Standard");
	const [character, setCharacter] = (0, import_react.useState)("");
	const [series, setSeries] = (0, import_react.useState)("");
	const [license, setLicense] = (0, import_react.useState)("");
	const [year, setYear] = (0, import_react.useState)(String((/* @__PURE__ */ new Date()).getFullYear()));
	const [finish, setFinish] = (0, import_react.useState)("matte");
	const [exclusiveKind, setExclusiveKind] = (0, import_react.useState)("none");
	const [retailer, setRetailer] = (0, import_react.useState)("");
	const [convention, setConvention] = (0, import_react.useState)("");
	const [sticker, setSticker] = (0, import_react.useState)("");
	const [edition, setEdition] = (0, import_react.useState)("");
	const [chase, setChase] = (0, import_react.useState)(false);
	const [ratio, setRatio] = (0, import_react.useState)("");
	const [upc, setUpc] = (0, import_react.useState)("");
	const [country, setCountry] = (0, import_react.useState)("United States");
	const [msrp, setMsrp] = (0, import_react.useState)("11.99");
	const [production, setProduction] = (0, import_react.useState)("Vaulted");
	const [size, setSize] = (0, import_react.useState)("Standard");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function save() {
		if (!name.trim() || !number.trim()) {
			setError("Name and box number are required.");
			return;
		}
		const who = character.trim() || name.trim();
		const line = series.trim() || "Custom";
		const id = `C${Date.now().toString(36)}`;
		addCustom({
			id,
			number: number.trim(),
			name: name.trim(),
			character: who,
			characterKey: slug(who),
			series: line,
			line: "Pop!",
			license: license.trim() || "Unknown",
			year: Number(year) || (/* @__PURE__ */ new Date()).getFullYear(),
			country: country.trim() || "Unknown",
			familyId: `${slug(line)}-${number.trim().replace(/\s+/g, "")}`,
			variant: variant.trim() || "Standard",
			isChase: chase,
			chaseRatio: chase ? ratio.trim() || void 0 : void 0,
			exclusiveKind,
			retailer: retailer.trim() || void 0,
			convention: convention.trim() || void 0,
			editionSize: edition.trim() ? Number(edition) : void 0,
			sticker: sticker.trim() || void 0,
			upc: upc.trim() || void 0,
			msrp: Number(msrp) || 0,
			production,
			finish,
			size: size.trim() || "Standard",
			palette: paint[finish],
			notes: notes.trim() || "Added by you. Not from a price feed.",
			sales: []
		});
		navigate({
			to: "/record/$id",
			params: { id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Catalog",
				title: "Add a figure",
				lede: "The starter ledger is not every Pop in circulation. Add the one in your hand. Same line and box number will link as variants. Price it afterward by logging a sale."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Product name",
						value: name,
						onChange: setName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Box number",
						value: number,
						onChange: setNumber,
						placeholder: "239"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Variant",
						value: variant,
						onChange: setVariant
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Character",
						value: character,
						onChange: setCharacter
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Series",
						value: series,
						onChange: setSeries,
						placeholder: "Movies"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "License",
						value: license,
						onChange: setLicense
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Release year",
						value: year,
						onChange: setYear
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Country",
						value: country,
						onChange: setCountry
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-mute",
						children: ["Finish", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: `${field} mt-1`,
							value: finish,
							onChange: (e) => setFinish(e.target.value),
							children: finishes.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-mute",
						children: ["Exclusive type", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: `${field} mt-1`,
							value: exclusiveKind,
							onChange: (e) => setExclusiveKind(e.target.value),
							children: exclusives.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Exclusive retailer",
						value: retailer,
						onChange: setRetailer
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Convention",
						value: convention,
						onChange: setConvention
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Sticker",
						value: sticker,
						onChange: setSticker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Edition size",
						value: edition,
						onChange: setEdition,
						placeholder: "480"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "UPC",
						value: upc,
						onChange: setUpc
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Original retail",
						value: msrp,
						onChange: setMsrp
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Size",
						value: size,
						onChange: setSize
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-mute",
						children: ["Production", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: `${field} mt-1`,
							value: production,
							onChange: (e) => setProduction(e.target.value),
							children: productions.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center gap-3 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: chase,
							onChange: (e) => setChase(e.target.checked)
						}), "Chase"]
					}),
					chase && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Chase ratio",
						value: ratio,
						onChange: setRatio,
						placeholder: "1/6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-mute sm:col-span-2",
						children: ["Notes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${field} mt-1 min-h-24 py-2`,
							value: notes,
							onChange: (e) => setNotes(e.target.value)
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-dim",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${btnAmber} self-start`,
				onClick: save,
				children: "Save figure"
			})
		]
	});
}
function Field({ label, value, onChange, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "text-sm text-mute",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: `${field} mt-1`,
			value,
			placeholder,
			onChange: (e) => onChange(e.target.value)
		})]
	});
}
//#endregion
export { AddPage as component };
