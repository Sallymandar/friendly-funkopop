import { n as figures } from "./catalog-BXF-4cw1.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identify.functions-DpPWls3x.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var matchPhoto_createServerFn_handler = createServerRpc({
	id: "78ddb1f518c17eeca60e42287c703c5bbeca71ae44a7a068dc242dbe01e6780d",
	name: "matchPhoto",
	filename: "src/lib/identify.functions.ts"
}, (opts) => matchPhoto.__executeServer(opts));
var matchPhoto = createServerFn({ method: "POST" }).validator((data) => {
	const image = data && typeof data === "object" && "image" in data ? data.image : "";
	if (typeof image !== "string" || !image.startsWith("data:image/")) throw new Error("Need a JPEG or PNG.");
	if (image.length > 5e5) throw new Error("That photo is too large. Try a closer crop.");
	return { image };
}).handler(matchPhoto_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Photo match isn’t available right now. Use the questions below."
	};
	const index = figures.map((f) => `${f.id} | #${f.number} ${f.name} | ${f.variant} | ${f.series} | ${f.year} | ${f.finish} | ${f.sticker ?? "no sticker"} | ${f.exclusiveKind}${f.retailer ? " " + f.retailer : ""}${f.convention ? " " + f.convention : ""}`).join("\n");
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 350,
			messages: [{
				role: "system",
				content: "You match a photo of a vinyl collectible to a closed ledger. Only use ids from the ledger. Never invent a figure. If nothing fits, return an empty list. Reply with JSON only: {\"matches\":[{\"id\":\"F000001\",\"confidence\":\"high|medium|low\",\"because\":\"short reason\"}]}. At most 3 matches, best first."
			}, {
				role: "user",
				content: [{
					type: "text",
					text: `Ledger:\n${index}\n\nWhich ledger rows could this photo be?`
				}, {
					type: "image_url",
					image_url: {
						url: data.image,
						detail: "low"
					}
				}]
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `Photo match failed (${res.status}). Try the questions below.`
	};
	const raw = ((await res.json()).choices?.[0]?.message?.content ?? "").match(/\{[\s\S]*\}/)?.[0];
	if (!raw) return {
		ok: false,
		error: "No match came back. Try the questions below."
	};
	try {
		const parsed = JSON.parse(raw);
		const known = new Set(figures.map((f) => f.id));
		return {
			ok: true,
			matches: (parsed.matches ?? []).filter((m) => m.id && known.has(m.id)).slice(0, 3).map((m) => ({
				id: m.id,
				confidence: m.confidence === "high" || m.confidence === "medium" ? m.confidence : "low",
				because: (m.because ?? "").slice(0, 180)
			}))
		};
	} catch {
		return {
			ok: false,
			error: "Couldn’t read the match. Try the questions below."
		};
	}
});
//#endregion
export { matchPhoto_createServerFn_handler };
