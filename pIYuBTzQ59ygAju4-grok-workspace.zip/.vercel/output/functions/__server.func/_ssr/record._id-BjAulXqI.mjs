import { i as __toESM } from "../_runtime.mjs";
import { a as resolveFigure, i as othersOfCharacter, t as familyOf } from "./catalog-BXF-4cw1.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useShelf, c as emptyHolding, d as money, f as quote, g as useHydrated, h as summarize, l as field, n as FigureLink, o as btnAmber, r as Gain, s as btnGhost, t as Badges, u as formatWhen } from "./shelf-C96d3s3d.mjs";
import { n as Route } from "./router-aYaoQcLy.mjs";
import { t as VinylPlate } from "./vinyl-UzJl_sOE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/record._id-BjAulXqI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CompsChart({ sales }) {
	const [Inner, setInner] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		import("./comps-chart-inner-DEvDk1Fn.mjs").then((m) => setInner(() => m.CompsChartInner));
	}, []);
	if (!Inner) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-44 rounded-2xl bg-ink" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inner, { sales });
}
var angles = [
	{
		id: "front",
		label: "Front"
	},
	{
		id: "back",
		label: "Back"
	},
	{
		id: "side",
		label: "Side"
	},
	{
		id: "bottom",
		label: "Bottom"
	},
	{
		id: "sticker",
		label: "Sticker"
	},
	{
		id: "barcode",
		label: "Barcode"
	}
];
var conditions = [
	"Mint",
	"Near Mint",
	"Good",
	"Damaged"
];
function RecordPage() {
	const { id } = Route.useParams();
	const custom = useShelf((s) => s.custom);
	const figure = resolveFigure(id, custom);
	const hydrated = useHydrated();
	if (!figure) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl",
		children: "Not in the ledger"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/catalog",
		search: {
			q: "",
			lens: "all",
			family: "",
			series: ""
		},
		className: "mt-4 inline-flex min-h-11 items-center text-amber",
		children: "Back to catalog"
	})] });
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-mute",
		children: "Opening the record…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordBody, { figure }, id);
}
function RecordBody({ figure }) {
	const holding = useShelf((s) => s.holdings.find((h) => h.recordId === figure.id));
	const want = useShelf((s) => s.wants.find((w) => w.recordId === figure.id));
	const upsert = useShelf((s) => s.upsertHolding);
	const remove = useShelf((s) => s.removeHolding);
	const upsertWant = useShelf((s) => s.upsertWant);
	const removeWant = useShelf((s) => s.removeWant);
	const logSale = useShelf((s) => s.logSale);
	const removeSale = useShelf((s) => s.removeSale);
	const custom = useShelf((s) => s.custom);
	const allSales = useShelf((s) => s.sales);
	const logged = allSales.filter((s) => s.recordId === figure.id);
	const [angle, setAngle] = (0, import_react.useState)("front");
	const [draft, setDraft] = (0, import_react.useState)(holding ?? emptyHolding(figure.id));
	const [photoAngle, setPhotoAngle] = (0, import_react.useState)("Front");
	const [photoError, setPhotoError] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)("");
	const [salePrice, setSalePrice] = (0, import_react.useState)("");
	const [saleDate, setSaleDate] = (0, import_react.useState)(() => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [saleCondition, setSaleCondition] = (0, import_react.useState)("Mint");
	const [salePlatform, setSalePlatform] = (0, import_react.useState)("eBay");
	const family = (0, import_react.useMemo)(() => familyOf(figure, custom), [figure, custom]);
	const others = (0, import_react.useMemo)(() => othersOfCharacter(figure, custom), [figure, custom]);
	const market = quote(figure.sales, logged, draft.box);
	const chaseSibling = family.find((f) => f.isChase);
	function save(next) {
		if (next.photos.reduce((n, p) => n + p.dataUrl.length, 0) > 35e5) {
			setPhotoError("This shelf is full. Remove a photo first.");
			return;
		}
		upsert(next);
		setDraft(next);
		setSaved("Saved on this device.");
	}
	async function addPhoto(file) {
		setPhotoError("");
		try {
			const dataUrl = await shrink(file);
			save({
				...draft,
				photos: [...draft.photos, {
					id: crypto.randomUUID(),
					angle: photoAngle,
					dataUrl
				}].slice(0, 6)
			});
		} catch (err) {
			setPhotoError(err instanceof Error ? err.message : "Couldn’t read that photo.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/catalog",
					search: {
						q: "",
						lens: "all",
						family: figure.familyId,
						series: ""
					},
					className: "text-sm text-amber",
					children: [
						figure.name,
						" #",
						figure.number,
						" · ",
						family.length,
						" known variants"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl sm:text-5xl",
					children: figure.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-lg text-dim",
					children: figure.variant
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badges, { figure })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-[280px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VinylPlate, {
						figure,
						angle,
						large: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: angles.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `min-h-11 rounded-full px-3 text-sm ${angle === a.id ? "bg-amber text-amber-ink" : "border border-line text-paper"}`,
							onClick: () => setAngle(a.id),
							children: a.label
						}, a.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-mute",
						children: "Paint plate, not a product photo. Your own photos sit on the shelf copy."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-panel p-4 sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Record"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid grid-cols-1 gap-x-6 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Funko ID",
									v: figure.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Item number",
									v: figure.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Character",
									v: figure.character
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Series",
									v: figure.series
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Line",
									v: figure.line
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "License",
									v: figure.license
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Release year",
									v: String(figure.year)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Size",
									v: figure.size
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Country",
									v: figure.country
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Box style",
									v: figure.boxStyle ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Finish",
									v: figure.finish
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Production",
									v: figure.production
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Original retail",
									v: money(figure.msrp, true)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "UPC",
									v: figure.upc ?? "Not on file"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-dim",
							children: figure.notes
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-2xl",
					children: [
						figure.name,
						" #",
						figure.number,
						" — ",
						family.length,
						" known variants"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2",
					children: family.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FigureLink, {
						figure: f,
						detail: (() => {
							const rows = allSales.filter((s) => s.recordId === f.id);
							return rows.length ? money(summarize(rows).estimate) : "Unpriced";
						})()
					}) }, f.id))
				}),
				others.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "mt-6 font-display text-xl",
					children: [
						"Other ",
						figure.character,
						" numbers"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2",
					children: others.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FigureLink, {
						figure: f,
						detail: `#${f.number}`
					}) }, f.id))
				})] })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-panel p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Exclusive"
					}), figure.exclusiveKind === "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-dim",
						children: "Common release. No retailer, convention, or shared sticker."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								k: "Type",
								v: figure.exclusiveKind
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								k: "Retailer",
								v: figure.retailer ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								k: "Convention",
								v: figure.convention ?? "None"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								k: "Edition",
								v: figure.editionSize ? `${figure.editionSize.toLocaleString()} pieces` : "Not numbered"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								k: "Sticker",
								v: figure.sticker ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
								k: "Release",
								v: String(figure.year)
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-panel p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Chase"
						}),
						figure.isChase ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-dim",
							children: "This is the chase of the family."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-amber",
							children: ["Chase ratio ", figure.chaseRatio ?? "—"]
						})] }) : chaseSibling ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-dim",
							children: [
								"Standard of this number. Chase sibling:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/record/$id",
									params: { id: chaseSibling.id },
									className: "text-amber",
									children: chaseSibling.variant
								}),
								chaseSibling.chaseRatio ? ` · ${chaseSibling.chaseRatio}` : "",
								"."
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-dim",
							children: "No chase sibling in this family. Exclusives are tracked separately."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 flex min-h-11 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: draft.pulledChase,
								onChange: (e) => setDraft({
									...draft,
									pulledChase: e.target.checked
								})
							}), "I pulled the chase myself"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-panel p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Value"
						}), market.source === "logged" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-mute",
							children: [
								"From ",
								market.count,
								" sales you logged"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl tabular-nums",
							children: money(market.estimate)
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-mute",
							children: "No verified price"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl",
							children: "Log a sale"
						})] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-dim",
							children: market.source === "logged" ? `Your copy, ${draft.box} box: ${money(market.unit)}` : "Log a sale to price this copy"
						})]
					}),
					market.source === "logged" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
								k: "Low",
								v: money(market.low)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
								k: "Average",
								v: money(market.average)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
								k: "High",
								v: money(market.high)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						onSubmit: (e) => {
							e.preventDefault();
							const price = Number(salePrice);
							if (!Number.isFinite(price) || price <= 0) return;
							logSale({
								id: crypto.randomUUID(),
								recordId: figure.id,
								date: saleDate,
								price: Math.round(price),
								condition: saleCondition,
								platform: salePlatform
							});
							setSalePrice("");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: ["Sale date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `${field} mt-1`,
									type: "date",
									value: saleDate,
									onChange: (e) => setSaleDate(e.target.value),
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: ["Price", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `${field} mt-1`,
									type: "number",
									min: 1,
									step: 1,
									value: salePrice,
									onChange: (e) => setSalePrice(e.target.value),
									placeholder: "85",
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: ["Condition", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: `${field} mt-1`,
									value: saleCondition,
									onChange: (e) => setSaleCondition(e.target.value),
									children: conditions.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: ["Platform", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: `${field} mt-1`,
									value: salePlatform,
									onChange: (e) => setSalePlatform(e.target.value),
									children: [
										"eBay",
										"Whatnot",
										"Mercari",
										"Shop",
										"Other"
									].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: p }, p))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: `${btnAmber} sm:col-span-2 sm:justify-self-start`,
								children: "Log this sale"
							})
						]
					}),
					logged.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompsChart, { sales: logged })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaleTable, {
						rows: logged,
						onRemove: (id) => removeSale(id)
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-panel p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Your copy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mute",
						children: "Saved on this device. Not a shared account."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: ["Quantity", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `${field} mt-1`,
									type: "number",
									min: 1,
									value: draft.qty,
									onChange: (e) => setDraft({
										...draft,
										qty: Math.max(1, Number(e.target.value) || 1)
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: ["Paid each", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `${field} mt-1`,
									type: "number",
									min: 0,
									value: draft.paid,
									onChange: (e) => setDraft({
										...draft,
										paid: Math.max(0, Number(e.target.value) || 0)
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Box",
								value: draft.box,
								onChange: (box) => setDraft({
									...draft,
									box
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								label: "Figure",
								value: draft.figure,
								onChange: (fig) => setDraft({
									...draft,
									figure: fig
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute sm:col-span-2",
								children: ["Edition number on your copy", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `${field} mt-1`,
									value: draft.editionNumber,
									placeholder: "128 / 480",
									onChange: (e) => setDraft({
										...draft,
										editionNumber: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute sm:col-span-2",
								children: ["Collector notes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: `${field} mt-1 min-h-24 py-2`,
									value: draft.notes,
									onChange: (e) => setDraft({
										...draft,
										notes: e.target.value
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: draft.grail,
									onChange: (e) => setDraft({
										...draft,
										grail: e.target.checked
									})
								}), "Grail"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: draft.forSale,
									onChange: (e) => setDraft({
										...draft,
										forSale: e.target.checked
									})
								}), "For sale"]
							}),
							draft.forSale && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: ["Asking", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `w-full min-h-11 rounded-xl border border-line bg-ink px-3 text-base text-paper placeholder:text-mute mt-1`,
									type: "number",
									min: 0,
									value: draft.ask ?? "",
									onChange: (e) => setDraft({
										...draft,
										ask: e.target.value === "" ? null : Number(e.target.value)
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 rounded-2xl border border-line p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-xl",
								children: "Photos of your copy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "min-h-11 rounded-xl border border-line bg-ink px-2",
									value: photoAngle,
									onChange: (e) => setPhotoAngle(e.target.value),
									children: [
										"Front",
										"Back",
										"Side",
										"Bottom",
										"Sticker",
										"Barcode",
										"Box damage",
										"Figure"
									].map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: a }, a))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: `${btnGhost} cursor-pointer`,
									children: ["Add photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/*",
										className: "sr-only",
										onChange: (e) => {
											const file = e.target.files?.[0];
											e.target.value = "";
											if (file) addPhoto(file);
										}
									})]
								})]
							}),
							photoError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-dim",
								children: photoError
							}),
							draft.photos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3",
								children: draft.photos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "overflow-hidden rounded-xl border border-line",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: photo.dataUrl,
										alt: photo.angle,
										className: "aspect-square w-full object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between px-2 py-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-mute",
											children: photo.angle
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 px-2 text-sm text-amber",
											onClick: () => setDraft({
												...draft,
												photos: draft.photos.filter((p) => p.id !== photo.id)
											}),
											children: "Remove"
										})]
									})]
								}, photo.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnAmber,
								onClick: () => save(draft),
								children: holding ? "Update shelf" : "Add to shelf"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnGhost,
								onClick: () => {
									upsertWant(want ?? {
										recordId: figure.id,
										ceiling: null,
										note: ""
									});
									setSaved("On your want list.");
								},
								children: want ? "On want list" : "Want list"
							}),
							holding && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnGhost,
								onClick: () => {
									remove(figure.id);
									setSaved("Removed from shelf.");
								},
								children: "Remove"
							}),
							want && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnGhost,
								onClick: () => removeWant(figure.id),
								children: "Drop want"
							})
						]
					}),
					saved && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-amber",
						children: saved
					}),
					holding && market.source === "logged" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-dim",
						children: [
							"Line value ",
							money(market.unit * holding.qty),
							" · in at ",
							money(holding.paid * holding.qty),
							" ·",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gain, { n: market.unit * holding.qty - holding.paid * holding.qty })
						]
					})
				]
			})
		]
	});
}
function Fact({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-line py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-sm text-mute",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-paper",
			children: v
		})]
	});
}
function Mini({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-mute",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-2xl tabular-nums",
		children: v
	})] });
}
function Choice({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
		className: "text-sm text-mute",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1 flex flex-wrap gap-2",
		children: conditions.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: `min-h-11 rounded-full px-3 text-sm ${value === c ? "bg-amber text-amber-ink" : "border border-line"}`,
			onClick: () => onChange(c),
			children: c
		}, c))
	})] });
}
function SaleTable({ rows, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[32rem] text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-mute",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Date"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Price"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Condition"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Platform"
					}),
					onRemove && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: " "
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [...rows].sort((a, b) => b.date.localeCompare(a.date)).map((sale) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2 tabular-nums",
						children: formatWhen(sale.date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2 tabular-nums",
						children: money(sale.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2",
						children: sale.condition
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2",
						children: sale.platform
					}),
					onRemove && sale.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 text-amber",
							onClick: () => onRemove(sale.id),
							children: "Remove"
						})
					})
				]
			}, sale.id ?? `${sale.date}-${sale.price}-${sale.platform}`)) })]
		})
	});
}
async function shrink(file) {
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, 720 / Math.max(bitmap.width, bitmap.height));
	const canvas = document.createElement("canvas");
	canvas.width = Math.max(1, Math.round(bitmap.width * scale));
	canvas.height = Math.max(1, Math.round(bitmap.height * scale));
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Couldn’t read that photo.");
	ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
	const url = canvas.toDataURL("image/jpeg", .72);
	if (url.length > 4e5) throw new Error("Still too large after shrinking.");
	return url;
}
//#endregion
export { RecordPage as component };
