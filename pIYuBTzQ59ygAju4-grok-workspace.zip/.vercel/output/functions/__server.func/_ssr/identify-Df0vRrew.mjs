import { i as __toESM } from "../_runtime.mjs";
import { n as figures, s as seriesNames } from "./catalog-BXF-4cw1.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useShelf, c as emptyHolding, d as money, f as quote, i as PageHeader, l as field, o as btnAmber, s as btnGhost } from "./shelf-C96d3s3d.mjs";
import { t as VinylPlate } from "./vinyl-UzJl_sOE.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identify-Df0vRrew.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var matchPhoto = createServerFn({ method: "POST" }).validator((data) => {
	const image = data && typeof data === "object" && "image" in data ? data.image : "";
	if (typeof image !== "string" || !image.startsWith("data:image/")) throw new Error("Need a JPEG or PNG.");
	if (image.length > 5e5) throw new Error("That photo is too large. Try a closer crop.");
	return { image };
}).handler(createSsrRpc("78ddb1f518c17eeca60e42287c703c5bbeca71ae44a7a068dc242dbe01e6780d"));
var finishes = [
	"",
	"matte",
	"metallic",
	"flocked",
	"glow",
	"chrome"
];
var stickers = [
	{
		id: "",
		label: "Any sticker"
	},
	{
		id: "chase",
		label: "Chase sticker"
	},
	{
		id: "exclusive",
		label: "Retailer or show"
	},
	{
		id: "none",
		label: "No special sticker"
	}
];
function IdentifyPage() {
	const [number, setNumber] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [series, setSeries] = (0, import_react.useState)("");
	const [finish, setFinish] = (0, import_react.useState)("");
	const [sticker, setSticker] = (0, import_react.useState)("");
	const [photoUrl, setPhotoUrl] = (0, import_react.useState)("");
	const [photoError, setPhotoError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [photoNote, setPhotoNote] = (0, import_react.useState)("");
	const [photoMatches, setPhotoMatches] = (0, import_react.useState)([]);
	const [added, setAdded] = (0, import_react.useState)("");
	const upsert = useShelf((s) => s.upsertHolding);
	const custom = useShelf((s) => s.custom);
	const pool = (0, import_react.useMemo)(() => [...custom, ...figures], [custom]);
	const scored = (0, import_react.useMemo)(() => {
		return pool.map((figure) => ({
			figure,
			score: scoreFigure(figure, {
				number,
				name,
				series,
				finish,
				sticker
			})
		})).filter((row) => row.score > 0).sort((a, b) => b.score - a.score).slice(0, 8);
	}, [
		number,
		name,
		series,
		finish,
		sticker,
		pool
	]);
	const asked = number || name || series || finish || sticker;
	async function onPhoto(file) {
		setPhotoError("");
		setPhotoNote("");
		setPhotoMatches([]);
		try {
			const bitmap = await createImageBitmap(file);
			const scale = Math.min(1, 640 / Math.max(bitmap.width, bitmap.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(bitmap.width * scale));
			canvas.height = Math.max(1, Math.round(bitmap.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("Couldn’t read that photo.");
			ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
			const url = canvas.toDataURL("image/jpeg", .7);
			if (url.length > 45e4) throw new Error("Crop in closer — that photo is too heavy.");
			setPhotoUrl(url);
		} catch (err) {
			setPhotoError(err instanceof Error ? err.message : "Couldn’t read that photo.");
		}
	}
	async function runMatch() {
		if (!photoUrl) return;
		setBusy(true);
		setPhotoNote("");
		setPhotoMatches([]);
		try {
			const result = await matchPhoto({ data: { image: photoUrl } });
			if (!result.ok) {
				setPhotoNote(result.error);
				return;
			}
			setPhotoMatches(result.matches);
			if (result.matches.length === 0) setPhotoNote("Nothing in this starter ledger looks like that photo.");
		} catch {
			setPhotoNote("Photo match didn’t answer. Use the questions below.");
		} finally {
			setBusy(false);
		}
	}
	function add(figure) {
		upsert({
			...emptyHolding(figure.id),
			paid: 0
		});
		setAdded(`${figure.name} #${figure.number} is on your shelf.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Identify",
				title: "What number is on the box?",
				lede: "Narrow the starter ledger by number, finish, and sticker. A photo is a second opinion — it only suggests rows already in FunkoDB, and only when you ask."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Photo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: `${btnGhost} cursor-pointer`,
							children: ["Choose a photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								className: "sr-only",
								onChange: (e) => {
									const file = e.target.files?.[0];
									e.target.value = "";
									if (file) onPhoto(file);
								}
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: btnAmber,
							disabled: !photoUrl || busy,
							onClick: () => void runMatch(),
							children: busy ? "Matching…" : "Match this photo"
						})]
					}),
					photoUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: photoUrl,
						alt: "Figure you want identified",
						className: "mt-3 h-40 w-40 rounded-xl object-cover"
					}),
					photoError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-dim",
						children: photoError
					}),
					photoNote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-dim",
						children: photoNote
					}),
					photoMatches.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-3",
						children: photoMatches.map((match) => {
							const figure = pool.find((f) => f.id === match.id);
							if (!figure) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
								figure,
								because: match.because,
								confidence: match.confidence,
								onAdd: () => add(figure)
							}, match.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-mute",
						children: ["Box number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${field} mt-1`,
							value: number,
							onChange: (e) => setNumber(e.target.value),
							placeholder: "239"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-mute",
						children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${field} mt-1`,
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Godzilla"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-mute",
						children: ["Line", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: `${field} mt-1`,
							value: series,
							onChange: (e) => setSeries(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Any line"
							}), seriesNames.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-mute",
						children: ["Finish", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: `${field} mt-1`,
							value: finish,
							onChange: (e) => setFinish(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Any finish"
							}), finishes.filter(Boolean).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: f,
								children: f
							}, f))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm text-mute",
							children: "Sticker"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: stickers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `min-h-11 rounded-full px-4 ${sticker === s.id ? "bg-amber text-amber-ink" : "border border-line"}`,
								onClick: () => setSticker(s.id),
								children: s.label
							}, s.id || "any"))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Possible matches"
				}),
				!asked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-dim",
					children: "Enter a number or a name to search the ledger."
				}) : scored.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-dim",
					children: "No row fits those answers."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-3",
					children: scored.map(({ figure }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
						figure,
						onAdd: () => add(figure)
					}) }, figure.id))
				}),
				added && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-amber",
					children: added
				})
			] })
		]
	});
}
function MatchCard({ figure, because, confidence, onAdd }) {
	const sales = useShelf((s) => s.sales);
	const priced = quote(figure.sales, sales.filter((s) => s.recordId === figure.id), "Mint");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 rounded-2xl border border-line bg-panel p-3 sm:grid-cols-[160px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VinylPlate, { figure }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-amber",
				children: confidence ? `${confidence} confidence` : "Ledger match"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/record/$id",
				params: { id: figure.id },
				className: "font-display text-2xl",
				children: [
					figure.line,
					" ",
					figure.name,
					" #",
					figure.number
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-dim",
				children: [
					figure.year,
					" · ",
					figure.variant,
					" · ",
					figure.series
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 tabular-nums",
				children: priced.source === "logged" ? `Verified ${money(priced.estimate)}` : "No verified price"
			}),
			because && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-mute",
				children: because
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${btnAmber} mt-3`,
				onClick: onAdd,
				children: "Yes — add to shelf"
			})
		] })]
	});
}
function scoreFigure(figure, q) {
	let score = 0;
	const num = q.number.trim().replace(/^0+/, "");
	if (num) {
		const theirs = figure.number.replace(/^0+/, "");
		if (theirs === num) score += 6;
		else if (theirs.includes(num)) score += 2;
		else return 0;
	}
	if (q.series) {
		if (figure.series === q.series) score += 2;
		else return 0;
	}
	if (q.finish) {
		if (figure.finish === q.finish) score += 3;
		else score -= 1;
	}
	if (q.sticker === "chase") score += figure.isChase ? 3 : -2;
	if (q.sticker === "exclusive") score += figure.exclusiveKind !== "none" ? 2 : -1;
	if (q.sticker === "none") score += !figure.isChase && figure.exclusiveKind === "none" ? 2 : -1;
	if (q.name.trim()) {
		if (`${figure.name} ${figure.character} ${figure.variant}`.toLowerCase().includes(q.name.trim().toLowerCase())) score += 4;
		else if (!num) return 0;
	}
	return score;
}
//#endregion
export { IdentifyPage as component };
