import { i as __toESM } from "../_runtime.mjs";
import { c as sets, n as figures, r as getFigure } from "./catalog-BXF-4cw1.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useShelf, a as Stat, d as money, i as PageHeader, l as field, m as signed, o as btnAmber, p as shelfMath } from "./shelf-C96d3s3d.mjs";
import { t as VinylPlate } from "./vinyl-UzJl_sOE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BfCQi2Ze.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const [q, setQ] = (0, import_react.useState)("");
	const navigate = useNavigate();
	const holdings = useShelf((s) => s.holdings);
	const custom = useShelf((s) => s.custom);
	const sales = useShelf((s) => s.sales);
	const math = shelfMath(holdings, custom, sales);
	const chases = figures.filter((f) => f.isChase);
	const families = new Set(figures.map((f) => f.familyId)).size;
	const spotlight = [
		"F000001",
		"F000010",
		"F000020"
	].map((id) => getFigure(id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "FunkoDB",
				title: "The ledger, priced only by sales.",
				lede: "Identity, exclusives, chase, shelf, want list, trades, and a price book. A rate counts only after you log or import a real sale. This is not a hobbyDB or Pop Price Guide scrape, and it is not every Pop in circulation."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3 sm:flex-row",
				onSubmit: (e) => {
					e.preventDefault();
					navigate({
						to: "/catalog",
						search: {
							q,
							lens: "all",
							family: "",
							series: ""
						}
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "q",
						children: "Search the ledger"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "q",
						className: field,
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search name, number, sticker, retailer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: btnAmber,
						type: "submit",
						children: "Search"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Records",
						value: String(figures.length + custom.length),
						hint: `${families} variant families in the starter set`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Verified value",
						value: money(math.verified),
						hint: math.unpriced ? `${math.unpriced} copies still unpriced` : `${math.copies} copies priced from your sales`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Amount invested",
						value: money(math.invested)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Gain on priced copies",
						value: signed(math.gain),
						hint: `${math.chases} chase · ${math.exclusives} exclusive`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-[1.4fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Families"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/catalog",
						search: {
							q: "",
							lens: "all",
							family: "",
							series: ""
						},
						className: "text-sm text-amber",
						children: "Full catalog"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: spotlight.map((figure) => {
						const count = figures.filter((f) => f.familyId === figure.familyId).length;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/catalog",
							search: {
								q: "",
								lens: "all",
								family: figure.familyId,
								series: ""
							},
							className: "block",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VinylPlate, { figure }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 font-medium",
									children: [
										figure.name,
										" #",
										figure.number
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mute",
									children: [count, " known variants"]
								})
							]
						}, figure.familyId);
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-panel p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Chase case"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-mute",
							children: "Standard and chase stay linked. Ratio is the cited case odds."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 flex flex-col gap-3",
							children: [chases.map((figure) => {
								const common = figures.find((f) => f.familyId === figure.familyId && !f.isChase);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/record/$id",
									params: { id: figure.id },
									className: "block",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-mute",
											children: common ? `${common.name} #${common.number}` : figure.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: figure.variant
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm text-amber",
											children: ["Chase ratio ", figure.chaseRatio]
										})
									]
								}) }, figure.id);
							}), chases.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-mute",
								children: "No chase rows yet."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sets",
							className: "mt-4 inline-flex min-h-11 items-center text-sm text-amber",
							children: [sets.length, " completion sets"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Price book"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/market",
						className: "text-sm text-amber",
						children: "Import sales"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mute",
					children: "Median of the mint and near-mint sales you entered. Nothing here is estimated from a third-party feed."
				}),
				sales.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 rounded-2xl border border-line bg-panel px-4 py-6 text-dim",
					children: "No sales yet. Open a record and log one, or import a sheet on Market."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2",
					children: sales.slice(0, 6).map((sale) => {
						const figure = getFigure(sale.recordId) ?? custom.find((f) => f.id === sale.recordId);
						if (!figure) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-panel px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/record/$id",
								params: { id: figure.id },
								className: "font-medium",
								children: [
									figure.name,
									" #",
									figure.number
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-mute",
								children: [
									figure.variant,
									" · ",
									sale.condition,
									" · ",
									sale.platform
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl tabular-nums",
								children: money(sale.price)
							})]
						}, sale.id);
					})
				})
			] })
		]
	});
}
//#endregion
export { Home as component };
