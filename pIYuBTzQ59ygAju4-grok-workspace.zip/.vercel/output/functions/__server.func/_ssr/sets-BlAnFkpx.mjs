import { i as __toESM } from "../_runtime.mjs";
import { c as sets, r as getFigure } from "./catalog-BXF-4cw1.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useShelf, i as PageHeader } from "./shelf-C96d3s3d.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sets-BlAnFkpx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SetsPage() {
	const holdings = useShelf((s) => s.holdings);
	const owned = (0, import_react.useMemo)(() => new Set(holdings.map((h) => h.recordId)), [holdings]);
	const totals = sets.reduce((acc, set) => {
		acc.need += set.recordIds.length;
		acc.have += set.recordIds.filter((id) => owned.has(id)).length;
		return acc;
	}, {
		have: 0,
		need: 0
	});
	const overall = totals.need ? Math.round(totals.have / totals.need * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Sets",
				title: "Completion",
				lede: "Each bar is a checklist in this ledger, not the entire real-world wave. Missing rows are figures we already know."
			}),
			holdings && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-3xl tabular-nums",
				children: [
					totals.have,
					" / ",
					totals.need,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-dim",
						children: [
							"tracked · ",
							overall,
							"%"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-4",
				children: sets.map((set) => {
					const have = set.recordIds.filter((id) => owned.has(id)).length;
					const pct = Math.round(have / set.recordIds.length * 100);
					const missing = set.recordIds.filter((id) => !owned.has(id));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-line bg-panel p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: set.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "tabular-nums text-dim",
									children: [
										have,
										" / ",
										set.recordIds.length,
										" · ",
										pct,
										"%"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-mute",
								children: set.blurb
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-2 overflow-hidden rounded-full bg-ink",
								"aria-hidden": true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-amber",
									style: { width: `${pct}%` }
								})
							}),
							missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-mute",
									children: "Missing"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-2 flex flex-col gap-1",
									children: missing.map((id) => {
										const figure = getFigure(id);
										if (!figure) return null;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/record/$id",
											params: { id },
											className: "inline-flex min-h-11 items-center text-paper",
											children: [
												figure.name,
												" #",
												figure.number,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "ml-2 text-mute",
													children: figure.variant
												})
											]
										}) }, id);
									})
								})]
							})
						]
					}, set.id);
				})
			})
		]
	});
}
//#endregion
export { SetsPage as component };
