import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vinyl-UzJl_sOE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VinylPlate({ figure, angle = "front", large = false }) {
	const uid = (0, import_react.useId)().replace(/:/g, "");
	const { head, body, accent } = figure.palette;
	const metal = figure.finish === "metallic" || figure.finish === "chrome";
	const showFace = angle === "front" || angle === "side";
	const shift = angle === "side" ? 26 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex flex-col rounded-2xl border border-line bg-panel-2 ${large ? "p-4" : "p-3"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-display text-lg tabular-nums text-paper",
					children: ["#", figure.number]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-mute",
					children: figure.finish
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `relative ${large ? "mt-2 h-64" : "mt-1 h-36"}`,
				children: angle === "sticker" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sticker, { figure }) : angle === "barcode" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Barcode, { id: figure.id }) : angle === "bottom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomStamp, { figure }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 220",
					className: "h-full w-full",
					role: "img",
					"aria-label": `${figure.name} ${figure.variant} paint plate`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
							id: `${uid}-m`,
							x1: "0",
							y1: "0",
							x2: "1",
							y2: "1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "0",
									stopColor: "#fff",
									stopOpacity: "0.55"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "0.45",
									stopColor: "#fff",
									stopOpacity: "0"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "1",
									stopColor: "#000",
									stopOpacity: "0.25"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pattern", {
							id: `${uid}-f`,
							width: "6",
							height: "6",
							patternUnits: "userSpaceOnUse",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "1.5",
								cy: "1.5",
								r: "1",
								fill: "#1a1406",
								opacity: "0.28"
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: 100 + shift,
							cy: "206",
							rx: "42",
							ry: "7",
							fill: "#000",
							opacity: "0.35"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							transform: `translate(${shift} 0)`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "62",
									y: "128",
									width: "16",
									height: "40",
									rx: "8",
									fill: body
								}),
								angle !== "side" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "122",
									y: "128",
									width: "16",
									height: "40",
									rx: "8",
									fill: body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "80",
									y: "122",
									width: "40",
									height: "62",
									rx: "16",
									fill: body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "100",
									cy: "146",
									r: "5",
									fill: accent
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "100",
									cy: "74",
									r: "46",
									fill: head
								}),
								figure.finish === "glow" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "100",
									cy: "74",
									r: "52",
									fill: "none",
									stroke: accent,
									strokeWidth: "6",
									opacity: "0.45"
								}),
								showFace && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "84",
									cy: "74",
									r: "6",
									fill: "#f3ead7"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "116",
									cy: "74",
									r: "6",
									fill: "#f3ead7"
								})] }),
								metal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "100",
									cy: "74",
									r: "46",
									fill: `url(#${uid}-m)`
								}),
								figure.finish === "flocked" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "100",
									cy: "74",
									r: "46",
									fill: `url(#${uid}-f)`
								}),
								figure.finish === "flocked" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "80",
									y: "122",
									width: "40",
									height: "62",
									rx: "16",
									fill: `url(#${uid}-f)`
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 truncate text-sm text-dim",
				children: figure.variant
			})
		]
	});
}
function Sticker({ figure }) {
	const text = figure.sticker ?? "No special sticker";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-[90%] rounded-lg border-2 border-dashed border-amber bg-ink px-4 py-5 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-mute",
				children: "Sticker"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-xl text-paper",
				children: text
			})]
		})
	});
}
function BottomStamp({ figure }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col items-center justify-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 w-28 rounded-[100%] border border-line bg-ink" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-display text-lg tabular-nums",
				children: ["#", figure.number]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mute",
				children: figure.production
			})
		]
	});
}
function Barcode({ id }) {
	const bars = Array.from(id).flatMap((ch, i) => {
		const n = ch.charCodeAt(0);
		return [
			n % 3 === 0,
			n % 2 === 0,
			i % 2 === 0
		];
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col items-center justify-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-16 items-end gap-px",
			"aria-hidden": true,
			children: bars.map((on, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `w-1 ${on ? "h-16 bg-paper" : "h-10 bg-dim"}` }, i))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-mute",
			children: "UPC not on file"
		})]
	});
}
//#endregion
export { VinylPlate as t };
