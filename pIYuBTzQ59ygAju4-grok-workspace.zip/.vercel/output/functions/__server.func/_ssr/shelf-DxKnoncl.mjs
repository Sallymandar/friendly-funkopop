import { a as resolveFigure, r as getFigure } from "./catalog-BXF-4cw1.mjs";
import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useShelf, a as Stat, d as money, f as quote, g as useHydrated, i as PageHeader, p as shelfMath, r as Gain, s as btnGhost } from "./shelf-C96d3s3d.mjs";
import { t as VinylPlate } from "./vinyl-UzJl_sOE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shelf-DxKnoncl.js
var import_jsx_runtime = require_jsx_runtime();
var vis = [
	"private",
	"friends",
	"public"
];
function ShelfPage() {
	const hydrated = useHydrated();
	const holdings = useShelf((s) => s.holdings);
	const custom = useShelf((s) => s.custom);
	const sales = useShelf((s) => s.sales);
	const visibility = useShelf((s) => s.visibility);
	const setVisibility = useShelf((s) => s.setVisibility);
	const resetSample = useShelf((s) => s.resetSample);
	const clearAll = useShelf((s) => s.clearAll);
	const math = shelfMath(holdings, custom, sales);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Shelf",
			title: "Your collection",
			lede: "Paid is what you put in. Value counts only from sales you logged, adjusted for box condition. Sample illustrations are left out of the total."
		}), !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-mute",
			children: "Opening your shelf…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Verified value",
						value: money(math.verified),
						hint: math.unpriced ? `${math.unpriced} copies have no logged sale` : `${math.copies} copies`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Amount invested",
						value: money(math.invested)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Gain on priced copies",
						value: math.gain >= 0 ? `+${money(math.gain)}` : `−${money(Math.abs(math.gain))}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Marks",
						value: `${math.chases} chase`,
						hint: `${math.grails} grail · ${math.exclusives} exclusive`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mute",
					children: "Visibility, saved here only"
				}), vis.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `min-h-11 rounded-full px-4 capitalize ${visibility === v ? "bg-amber text-amber-ink" : "border border-line"}`,
					onClick: () => setVisibility(v),
					children: v === "friends" ? "Friends only" : v
				}, v))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mute",
				children: "Sharing with other collectors waits on accounts. This choice stays on this device."
			}),
			holdings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-line bg-panel px-4 py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-dim",
					children: "The shelf is empty."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btnGhost} mt-4`,
					onClick: resetSample,
					children: "Load the sample shelf"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: holdings.map((h) => {
					const figure = resolveFigure(h.recordId, custom) ?? getFigure(h.recordId);
					if (!figure) return null;
					const q = quote(figure.sales, sales.filter((s) => s.recordId === h.recordId), h.box);
					const invested = h.paid * h.qty;
					const line = q.source === "logged" ? q.unit * h.qty : null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-3 rounded-2xl border border-line bg-panel p-3 sm:grid-cols-[140px_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VinylPlate, { figure }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/record/$id",
								params: { id: figure.id },
								className: "font-display text-2xl",
								children: figure.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-mute",
								children: [
									"#",
									figure.number,
									" · ",
									figure.variant,
									" · qty ",
									h.qty
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-dim",
								children: [
									h.box,
									" box · ",
									h.figure,
									" figure",
									h.grail ? " · Grail" : "",
									h.forSale ? ` · Asking ${money(h.ask ?? 0)}` : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid grid-cols-3 gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-mute",
										children: "Paid"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums",
										children: money(invested)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-mute",
										children: "Value"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums",
										children: line == null ? "Unpriced" : money(line)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-mute",
										children: "Gain"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: line == null ? "—" : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gain, { n: line - invested }) })] })
								]
							}),
							h.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-dim",
								children: h.notes
							})
						] })]
					}, h.recordId);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btnGhost,
					onClick: resetSample,
					children: "Reset sample shelf"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btnGhost,
					onClick: clearAll,
					children: "Clear shelf"
				})]
			})
		] })]
	});
}
//#endregion
export { ShelfPage as component };
