import { i as __toESM } from "../_runtime.mjs";
import { a as resolveFigure, n as figures, o as sampleShelves } from "./catalog-BXF-4cw1.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useShelf, d as money, f as quote, g as useHydrated, h as summarize, i as PageHeader, l as field, o as btnAmber } from "./shelf-C96d3s3d.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-PjZjCsE_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CONDITIONS = [
	"Mint",
	"Near Mint",
	"Good",
	"Damaged"
];
var PLATFORMS = [
	"eBay",
	"Whatnot",
	"Mercari",
	"Shop",
	"Other"
];
function looseNum(value) {
	return value.trim().replace(/^#/, "").replace(/^0+(?=\d)/, "") || "0";
}
function slug(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "figure";
}
function parseDate(raw) {
	const t = raw.trim();
	if (!t) return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	if (/^\d{4}-\d{2}-\d{2}$/.test(t)) return t;
	const us = t.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
	if (!us) return null;
	return `${us[3]}-${us[1].padStart(2, "0")}-${us[2].padStart(2, "0")}`;
}
function conditionOf(raw) {
	const t = raw.trim().toLowerCase();
	if (!t || t === "m" || t === "mint") return "Mint";
	if (t === "nm" || t === "near mint" || t === "nearmint") return "Near Mint";
	if (t === "g" || t === "good") return "Good";
	if (t === "d" || t === "dmg" || t === "damaged") return "Damaged";
	return CONDITIONS.find((c) => c.toLowerCase() === t) ?? null;
}
function platformOf(raw) {
	const t = raw.trim().toLowerCase();
	return PLATFORMS.find((p) => p.toLowerCase() === t) ?? "Other";
}
function cellsOf(line) {
	const out = [];
	let cur = "";
	let quoted = false;
	for (const ch of line) {
		if (ch === "\"") {
			quoted = !quoted;
			continue;
		}
		if (ch === "," && !quoted) {
			out.push(cur.trim());
			cur = "";
			continue;
		}
		cur += ch;
	}
	out.push(cur.trim());
	return out;
}
function paint(finish) {
	if (finish === "metallic") return {
		head: "#d5d8df",
		body: "#9aa0a8",
		accent: "#e4a322"
	};
	if (finish === "flocked") return {
		head: "#e6d3a1",
		body: "#c4b49a",
		accent: "#8a5a3a"
	};
	if (finish === "glow") return {
		head: "#d8ffb0",
		body: "#7dcc6a",
		accent: "#f4fff0"
	};
	if (finish === "chrome") return {
		head: "#e6c56b",
		body: "#c6a15a",
		accent: "#f3ead7"
	};
	return {
		head: "#c4b49a",
		body: "#8a8070",
		accent: "#e4a322"
	};
}
function blankFigure(input) {
	const who = input.name;
	const line = input.series || "Imported";
	const finish = "matte";
	return {
		id: `C${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
		number: input.number,
		name: who,
		character: who,
		characterKey: slug(who),
		series: line,
		line: "Pop!",
		license: "Unknown",
		year: input.year,
		country: "Unknown",
		familyId: `${slug(line)}-${input.number.replace(/\s+/g, "")}`,
		variant: input.variant || "Standard",
		isChase: false,
		exclusiveKind: "none",
		msrp: 0,
		production: "Vaulted",
		finish,
		size: "Standard",
		palette: paint(finish),
		notes: "Added from a sale import. Fill the record if the sticker or exclusive differs.",
		sales: []
	};
}
function parseCompCsv(text, custom) {
	const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
	const skipped = [];
	if (!lines.length) return {
		sales: [],
		created: [],
		skipped: ["The sheet was empty."],
		attached: 0
	};
	const first = cellsOf(lines[0]).map((c) => c.toLowerCase());
	const headed = first.includes("price");
	const keys = headed ? first : [
		"number",
		"name",
		"price",
		"date",
		"condition",
		"platform",
		"series",
		"variant"
	];
	const body = headed ? lines.slice(1) : lines;
	const pool = [...custom, ...figures];
	const created = [];
	const sales = [];
	body.forEach((line, index) => {
		const cells = cellsOf(line);
		const row = {};
		keys.forEach((key, i) => {
			row[key] = cells[i] ?? "";
		});
		const price = Number((row.price ?? "").replace(/[$,]/g, ""));
		if (!Number.isFinite(price) || price <= 0) {
			skipped.push(`Row ${index + 1}: price missing.`);
			return;
		}
		const date = parseDate(row.date ?? "");
		if (!date) {
			skipped.push(`Row ${index + 1}: date must be YYYY-MM-DD.`);
			return;
		}
		const condition = conditionOf(row.condition ?? "");
		if (!condition) {
			skipped.push(`Row ${index + 1}: condition must be Mint, Near Mint, Good, or Damaged.`);
			return;
		}
		const number = (row.number ?? row.box ?? "").trim();
		const name = (row.name ?? row.character ?? "").trim();
		const variant = (row.variant ?? "").trim();
		const series = (row.series ?? "").trim();
		const id = (row.id ?? "").trim();
		const year = Number(row.year) || (/* @__PURE__ */ new Date()).getFullYear();
		let match;
		if (id) match = pool.find((f) => f.id === id);
		const candidates = pool.filter((f) => {
			if (number && looseNum(f.number) !== looseNum(number)) return false;
			if (name && f.name.toLowerCase() !== name.toLowerCase() && f.character.toLowerCase() !== name.toLowerCase()) return false;
			if (series && f.series.toLowerCase() !== series.toLowerCase()) return false;
			if (variant && f.variant.toLowerCase() !== variant.toLowerCase()) return false;
			return Boolean(number || name);
		});
		if (!match) match = candidates.length === 1 ? candidates[0] : void 0;
		if (!match && candidates.length > 1) {
			skipped.push(`Row ${index + 1}: ${candidates.length} figures share that number. Add a variant column.`);
			return;
		}
		if (!match) {
			if (!name || !number) {
				skipped.push(`Row ${index + 1}: need a name and box number to add a new figure.`);
				return;
			}
			match = blankFigure({
				number,
				name,
				variant: variant || "Standard",
				series,
				year
			});
			created.push(match);
			pool.push(match);
		}
		sales.push({
			id: crypto.randomUUID(),
			recordId: match.id,
			date,
			price: Math.round(price),
			condition,
			platform: platformOf(row.platform ?? "")
		});
	});
	return {
		sales,
		created,
		skipped,
		attached: sales.length - created.length
	};
}
var sheetHint = `number,name,price,date,condition,platform,series,variant
239,Godzilla,42,2026-03-01,Mint,eBay,Movies,Standard
01,Batman,18,2026-04-12,Near Mint,Whatnot,Heroes,Standard`;
function MarketPage() {
	const hydrated = useHydrated();
	const holdings = useShelf((s) => s.holdings);
	const wants = useShelf((s) => s.wants);
	const custom = useShelf((s) => s.custom);
	const sales = useShelf((s) => s.sales);
	const importBatch = useShelf((s) => s.importBatch);
	const [haveId, setHaveId] = (0, import_react.useState)("");
	const [wantId, setWantId] = (0, import_react.useState)("");
	const [csv, setCsv] = (0, import_react.useState)("");
	const [report, setReport] = (0, import_react.useState)("");
	const have = holdings.find((h) => h.recordId === (haveId || holdings[0]?.recordId));
	const want = wants.find((w) => w.recordId === (wantId || wants[0]?.recordId));
	const haveFig = have ? resolveFigure(have.recordId, custom) : void 0;
	const wantFig = want ? resolveFigure(want.recordId, custom) : void 0;
	const haveQ = have && haveFig ? quote(haveFig.sales, sales.filter((s) => s.recordId === haveFig.id), have.box) : void 0;
	const wantQ = want && wantFig ? quote(wantFig.sales, sales.filter((s) => s.recordId === wantFig.id), "Mint") : void 0;
	const haveVal = haveQ?.source === "logged" ? haveQ.unit : null;
	const wantVal = wantQ?.source === "logged" ? wantQ.unit : null;
	const verifiedTrade = haveVal != null && wantVal != null;
	const diff = verifiedTrade ? wantVal - haveVal : 0;
	const mySaleIds = new Set(holdings.filter((h) => h.forSale).map((h) => h.recordId));
	const myWantIds = new Set(wants.map((w) => w.recordId));
	const book = [...sales].sort((a, b) => b.date.localeCompare(a.date));
	const byRecord = /* @__PURE__ */ new Map();
	for (const sale of sales) {
		const list = byRecord.get(sale.recordId) ?? [];
		list.push(sale);
		byRecord.set(sale.recordId, list);
	}
	function runImport() {
		const result = parseCompCsv(csv, custom);
		if (result.sales.length) importBatch(result.sales, result.created);
		const bits = [`Logged ${result.sales.length} sale${result.sales.length === 1 ? "" : "s"}.`];
		if (result.created.length) bits.push(`Added ${result.created.length} figure${result.created.length === 1 ? "" : "s"} that were not in the catalog.`);
		if (result.skipped.length) bits.push(result.skipped.slice(0, 4).join(" "));
		setReport(bits.join(" "));
		if (result.sales.length) setCsv("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Market",
			title: "Sales, wants, and trades.",
			lede: "Your price book is the sales you log or import. Asking prices are what a shelf is asking, not a market average. Sample shelves are examples, not other people’s accounts."
		}), !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-mute",
			children: "Opening the floor…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-panel p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Import sales"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mute",
						children: "One sale per line. If the box number matches more than one variant, include the variant column or the row is skipped."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: `${field} mt-3 min-h-36 py-3 font-mono text-sm`,
						value: csv,
						onChange: (e) => setCsv(e.target.value),
						placeholder: sheetHint,
						"aria-label": "Sale spreadsheet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `${btnAmber} mt-3`,
						onClick: runImport,
						disabled: !csv.trim(),
						children: "Add these sales"
					}),
					report && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-dim",
						children: report
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-panel p-4 sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Price book"
				}), book.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-dim",
					children: "No logged sales. Estimates stay blank until a sale lands here."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col",
					children: [...byRecord.entries()].map(([id, rows]) => {
						const figure = resolveFigure(id, custom);
						if (!figure) return null;
						const summary = summarize(rows);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-baseline justify-between gap-3 border-b border-line py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/record/$id",
								params: { id },
								className: "font-medium",
								children: [
									figure.name,
									" #",
									figure.number
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-mute",
								children: [
									figure.variant,
									" · ",
									summary.count,
									" sale",
									summary.count === 1 ? "" : "s"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-2xl tabular-nums",
									children: money(summary.estimate)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 block text-sm text-mute",
									children: [
										money(summary.low),
										" – ",
										money(summary.high)
									]
								})]
							})]
						}, id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
					title: "Want list",
					empty: "Nothing on the hunt.",
					children: wants.map((w) => {
						const figure = resolveFigure(w.recordId, custom);
						if (!figure) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-b border-line py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/record/$id",
									params: { id: figure.id },
									className: "font-medium",
									children: [
										figure.name,
										" #",
										figure.number
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mute",
									children: [figure.variant, w.ceiling != null ? ` · ceiling ${money(w.ceiling)}` : ""]
								}),
								w.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-dim",
									children: w.note
								})
							]
						}, w.recordId);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
					title: "For sale",
					empty: "Nothing listed from your shelf.",
					children: holdings.filter((h) => h.forSale).map((h) => {
						const figure = resolveFigure(h.recordId, custom);
						if (!figure) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-b border-line py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/record/$id",
								params: { id: figure.id },
								className: "font-medium",
								children: [
									figure.name,
									" #",
									figure.number
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-mute",
								children: [
									h.box,
									" · asking ",
									money(h.ask ?? 0)
								]
							})]
						}, h.recordId);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Trade gap"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mute",
						children: "Uses your logged sales only. A missing sale means the gap stays blank."
					}),
					holdings.length === 0 || wants.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-dim",
						children: "Add something you have and something you want."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: [
									"I have",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: `${field} mt-1`,
										value: have?.recordId ?? "",
										onChange: (e) => setHaveId(e.target.value),
										children: holdings.map((h) => {
											const figure = resolveFigure(h.recordId, custom);
											return figure ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: h.recordId,
												children: [
													figure.name,
													" #",
													figure.number
												]
											}, h.recordId) : null;
										})
									}),
									haveFig && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-paper",
										children: haveVal == null ? "No verified price" : `Verified ${money(haveVal)}`
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-mute",
								children: [
									"I want",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: `${field} mt-1`,
										value: want?.recordId ?? "",
										onChange: (e) => setWantId(e.target.value),
										children: wants.map((w) => {
											const figure = resolveFigure(w.recordId, custom);
											return figure ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: w.recordId,
												children: [
													figure.name,
													" #",
													figure.number
												]
											}, w.recordId) : null;
										})
									}),
									wantFig && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-paper",
										children: wantVal == null ? "No verified price" : `Verified ${money(wantVal)}`
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "sm:col-span-2 font-display text-3xl tabular-nums",
								children: verifiedTrade ? diff > 0 ? `You add ${money(diff)}` : diff < 0 ? `You come out ahead ${money(Math.abs(diff))}` : "Even trade" : "No rate yet"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Sample shelves"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-mute",
					children: "Example lists so a match against your wants is visible. Their asking numbers are sample asks, not comps."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-3 lg:grid-cols-3",
					children: sampleShelves.map((shelf) => {
						const hits = shelf.items.filter((i) => i.side !== "want" && myWantIds.has(i.recordId) || i.side === "want" && mySaleIds.has(i.recordId));
						const copies = shelf.items.filter((i) => i.side !== "want").reduce((n, i) => n + i.qty, 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl border border-line bg-panel p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl",
									children: shelf.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mute",
									children: [
										shelf.place,
										" · ",
										copies,
										" copies"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-dim",
									children: shelf.note
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 flex flex-col gap-2 text-sm",
									children: shelf.items.map((item, idx) => {
										const figure = resolveFigure(item.recordId, custom);
										if (!figure) return null;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-mute capitalize",
												children: [item.side, " · "]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/record/$id",
												params: { id: figure.id },
												children: [
													figure.name,
													" #",
													figure.number
												]
											}),
											item.ask != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-dim",
												children: [" · asking ", money(item.ask)]
											})
										] }, `${item.recordId}-${item.side}-${idx}`);
									})
								}),
								hits.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-amber",
									children: "Touches your want list or your for-sale."
								})
							]
						}, shelf.id);
					})
				})
			] })
		] })]
	});
}
function ListCard({ title, empty, children }) {
	const items = Array.isArray(children) ? children.filter(Boolean) : [children];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-panel p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: title
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-dim",
			children: empty
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2",
			children: items
		})]
	});
}
//#endregion
export { MarketPage as component };
