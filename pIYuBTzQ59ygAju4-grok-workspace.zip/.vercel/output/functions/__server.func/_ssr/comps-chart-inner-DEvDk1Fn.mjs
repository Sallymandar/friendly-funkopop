import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as money } from "./shelf-C96d3s3d.mjs";
import { n as format, t as parseISO } from "../_libs/date-fns.mjs";
import { a as ResponsiveContainer, i as Line, n as YAxis, o as Tooltip, r as XAxis, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/comps-chart-inner-DEvDk1Fn.js
var import_jsx_runtime = require_jsx_runtime();
function CompsChartInner({ sales }) {
	const data = [...sales].sort((a, b) => a.date.localeCompare(b.date)).map((s) => ({
		...s,
		label: format(parseISO(s.date), "MMM d")
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-44 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						tick: {
							fill: "var(--color-mute)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						hide: true,
						domain: ["dataMin - 8", "dataMax + 8"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: ({ active, payload }) => {
						if (!active || !payload?.length) return null;
						const row = payload[0]?.payload;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-line bg-panel px-3 py-2 text-sm text-paper",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "tabular-nums",
								children: money(row.price)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-mute",
								children: [
									row.condition,
									" · ",
									row.platform
								]
							})]
						});
					} }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "price",
						stroke: "var(--color-amber)",
						strokeWidth: 2,
						dot: {
							r: 3,
							fill: "var(--color-amber)"
						}
					})
				]
			})
		})
	});
}
//#endregion
export { CompsChartInner };
