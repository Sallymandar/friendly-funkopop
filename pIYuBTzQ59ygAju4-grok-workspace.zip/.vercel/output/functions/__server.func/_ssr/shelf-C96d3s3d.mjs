import { i as __toESM } from "../_runtime.mjs";
import { a as resolveFigure, r as getFigure } from "./catalog-BXF-4cw1.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shelf-C96d3s3d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BOX_FACTOR = {
	Mint: 1,
	"Near Mint": .88,
	Good: .62,
	Damaged: .35
};
function summarize(sales) {
	const all = sales.map((s) => s.price);
	const preferred = sales.filter((s) => s.condition === "Mint" || s.condition === "Near Mint");
	const pool = (preferred.length ? preferred : sales).map((s) => s.price).sort((a, b) => a - b);
	if (!all.length || !pool.length) return {
		low: 0,
		high: 0,
		average: 0,
		estimate: 0,
		count: 0
	};
	const mid = Math.floor(pool.length / 2);
	const estimate = pool.length % 2 === 1 ? pool[mid] : Math.round((pool[mid - 1] + pool[mid]) / 2);
	const sum = all.reduce((a, b) => a + b, 0);
	return {
		low: Math.min(...all),
		high: Math.max(...all),
		average: Math.round(sum / all.length),
		estimate,
		count: sales.length
	};
}
function quote(sample, logged, box) {
	const verified = summarize(logged);
	if (verified.count > 0) return {
		source: "logged",
		...verified,
		unit: Math.round(verified.estimate * BOX_FACTOR[box])
	};
	const illustration = summarize(sample);
	if (illustration.count > 0) return {
		source: "sample",
		...illustration,
		unit: Math.round(illustration.estimate * BOX_FACTOR[box])
	};
	return {
		source: "none",
		low: 0,
		high: 0,
		average: 0,
		estimate: 0,
		count: 0,
		unit: 0
	};
}
function money(n, cents = false) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: cents ? 2 : 0,
		minimumFractionDigits: cents ? 2 : 0
	}).format(n);
}
function signed(n) {
	const body = money(Math.abs(n));
	if (n > 0) return `+${body}`;
	if (n < 0) return `−${body}`;
	return body;
}
var field = "w-full min-h-11 rounded-xl border border-line bg-ink px-3 text-base text-paper placeholder:text-mute";
var btn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-4 text-base font-medium transition-opacity duration-200 hover:opacity-90 disabled:opacity-50";
var btnAmber = `${btn} bg-amber text-amber-ink`;
var btnGhost = `${btn} border border-line bg-transparent text-paper`;
function PageHeader({ kicker, title, lede }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-amber",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-4xl text-paper sm:text-5xl",
				children: title
			}),
			lede && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-base leading-relaxed text-dim",
				children: lede
			})
		]
	});
}
function Badges({ figure }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-2",
		children: [
			figure.isChase && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-amber px-2.5 py-1 text-sm font-medium text-amber-ink",
				children: "Chase"
			}),
			figure.exclusiveKind !== "none" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full border border-line px-2.5 py-1 text-sm text-paper",
				children: figure.exclusiveKind === "convention" ? "Convention" : figure.exclusiveKind === "shared" ? "Shared sticker" : "Retailer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full border border-line px-2.5 py-1 text-sm text-mute",
				children: figure.production
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-panel px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mute",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl tabular-nums text-paper",
				children: value
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-dim",
				children: hint
			})
		]
	});
}
function Gain({ n }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `tabular-nums ${n >= 0 ? "text-amber" : "text-dim"}`,
		children: signed(n)
	});
}
function FigureLink({ figure, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/record/$id",
		params: { id: figure.id },
		className: "block rounded-2xl border border-line bg-panel p-3 transition-colors duration-200 hover:border-dim",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-medium text-paper",
				children: [
					figure.name,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-mute",
						children: ["#", figure.number]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 text-sm tabular-nums text-dim",
				children: detail
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-mute",
			children: [
				figure.variant,
				" · ",
				figure.series,
				" · ",
				figure.year
			]
		})]
	});
}
function formatWhen(iso) {
	const [y, m, d] = iso.split("-");
	return `${[
		"Jan",
		"Feb",
		"Mar",
		"Apr",
		"May",
		"Jun",
		"Jul",
		"Aug",
		"Sep",
		"Oct",
		"Nov",
		"Dec"
	][Number(m) - 1]} ${Number(d)}, ${y}`;
}
var emptyHolding = (recordId) => ({
	recordId,
	qty: 1,
	box: "Mint",
	figure: "Mint",
	paid: 0,
	pulledChase: false,
	grail: false,
	forSale: false,
	ask: null,
	editionNumber: "",
	notes: "",
	photos: []
});
var sampleHoldings = [
	{
		...emptyHolding("F000010"),
		paid: 25
	},
	{
		...emptyHolding("F000001"),
		qty: 2,
		paid: 15,
		forSale: true,
		ask: 30
	},
	{
		...emptyHolding("F000020"),
		box: "Damaged",
		figure: "Good",
		paid: 8
	}
];
var sampleWants = [
	{
		recordId: "F000012",
		ceiling: 160,
		note: "NYCC glow, sticker on"
	},
	{
		recordId: "F000002",
		ceiling: 100,
		note: "Pulled or bought, either way"
	},
	{
		recordId: "F000021",
		ceiling: 40,
		note: "Flocked, not the smooth one"
	}
];
var useShelf = create()(persist((set) => ({
	holdings: sampleHoldings,
	wants: sampleWants,
	sales: [],
	custom: [],
	visibility: "private",
	upsertHolding: (h) => set((s) => ({ holdings: s.holdings.some((x) => x.recordId === h.recordId) ? s.holdings.map((x) => x.recordId === h.recordId ? h : x) : [h, ...s.holdings] })),
	removeHolding: (id) => set((s) => ({ holdings: s.holdings.filter((h) => h.recordId !== id) })),
	upsertWant: (w) => set((s) => ({ wants: s.wants.some((x) => x.recordId === w.recordId) ? s.wants.map((x) => x.recordId === w.recordId ? w : x) : [w, ...s.wants] })),
	removeWant: (id) => set((s) => ({ wants: s.wants.filter((w) => w.recordId !== id) })),
	logSale: (sale) => set((s) => ({ sales: [sale, ...s.sales.filter((x) => x.id !== sale.id)] })),
	removeSale: (id) => set((s) => ({ sales: s.sales.filter((x) => x.id !== id) })),
	addCustom: (figure) => set((s) => ({ custom: [figure, ...s.custom.filter((f) => f.id !== figure.id)] })),
	importBatch: (sales, created) => set((s) => ({
		sales: [...sales, ...s.sales],
		custom: [...created, ...s.custom.filter((f) => !created.some((c) => c.id === f.id))]
	})),
	setVisibility: (visibility) => set({ visibility }),
	resetSample: () => set({
		holdings: sampleHoldings,
		wants: sampleWants,
		visibility: "private"
	}),
	clearAll: () => set({
		holdings: [],
		wants: []
	})
}), { name: "funkodb-shelf-v1" }));
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(() => useShelf.persist.hasHydrated());
	(0, import_react.useEffect)(() => {
		setHydrated(useShelf.persist.hasHydrated());
		return useShelf.persist.onFinishHydration(() => setHydrated(true));
	}, []);
	return hydrated;
}
function shelfMath(holdings, custom = [], logged = []) {
	let copies = 0;
	let verified = 0;
	let verifiedCost = 0;
	let illustrated = 0;
	let invested = 0;
	let unpriced = 0;
	let chases = 0;
	let grails = 0;
	let exclusives = 0;
	for (const h of holdings) {
		const figure = resolveFigure(h.recordId, custom) ?? getFigure(h.recordId);
		if (!figure) continue;
		copies += h.qty;
		invested += h.paid * h.qty;
		const q = quote(figure.sales, logged.filter((s) => s.recordId === h.recordId), h.box);
		if (q.source === "logged") {
			verified += q.unit * h.qty;
			verifiedCost += h.paid * h.qty;
		} else if (q.source === "sample") {
			illustrated += q.unit * h.qty;
			unpriced += h.qty;
		} else unpriced += h.qty;
		if (figure.isChase) chases += h.qty;
		if (h.grail) grails += h.qty;
		if (figure.exclusiveKind !== "none") exclusives += h.qty;
	}
	return {
		copies,
		verified,
		illustrated,
		invested,
		gain: verified - verifiedCost,
		unpriced,
		chases,
		grails,
		exclusives
	};
}
//#endregion
export { useShelf as _, Stat as a, emptyHolding as c, money as d, quote as f, useHydrated as g, summarize as h, PageHeader as i, field as l, signed as m, FigureLink as n, btnAmber as o, shelfMath as p, Gain as r, btnGhost as s, Badges as t, formatWhen as u };
