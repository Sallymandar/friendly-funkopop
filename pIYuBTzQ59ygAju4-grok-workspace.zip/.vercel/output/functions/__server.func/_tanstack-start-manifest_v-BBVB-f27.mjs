//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BBVB-f27.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/add",
			"/catalog",
			"/identify",
			"/market",
			"/sets",
			"/shelf",
			"/record/$id"
		],
		preloads: [
			"/assets/index-CqDZAkZP.js",
			"/assets/jsx-runtime-D3jfb0Ew.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Bgx6RHhd.js",
			"/assets/preload-helper-De2xROTk.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CqDZAkZP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B63CH_Ip.js",
			"/assets/useNavigate-CPpy1WMz.js",
			"/assets/shelf-D5UEpQF1.js",
			"/assets/vinyl-BrU9ZyFL.js"
		]
	},
	"/add": {
		filePath: "/workspace/src/routes/add.tsx",
		children: void 0,
		preloads: [
			"/assets/add-CdiptyrQ.js",
			"/assets/useNavigate-CPpy1WMz.js",
			"/assets/shelf-D5UEpQF1.js"
		]
	},
	"/catalog": {
		filePath: "/workspace/src/routes/catalog.tsx",
		children: void 0,
		preloads: [
			"/assets/catalog-CuYcqIWY.js",
			"/assets/shelf-D5UEpQF1.js",
			"/assets/vinyl-BrU9ZyFL.js"
		]
	},
	"/identify": {
		filePath: "/workspace/src/routes/identify.tsx",
		children: void 0,
		preloads: [
			"/assets/identify-JMK6qFaq.js",
			"/assets/shelf-D5UEpQF1.js",
			"/assets/vinyl-BrU9ZyFL.js"
		]
	},
	"/market": {
		filePath: "/workspace/src/routes/market.tsx",
		children: void 0,
		preloads: ["/assets/market-DY3-EQKY.js", "/assets/shelf-D5UEpQF1.js"]
	},
	"/sets": {
		filePath: "/workspace/src/routes/sets.tsx",
		children: void 0,
		preloads: ["/assets/sets-B5rARx6F.js", "/assets/shelf-D5UEpQF1.js"]
	},
	"/shelf": {
		filePath: "/workspace/src/routes/shelf.tsx",
		children: void 0,
		preloads: [
			"/assets/shelf-DC8mYaBN.js",
			"/assets/shelf-D5UEpQF1.js",
			"/assets/vinyl-BrU9ZyFL.js"
		]
	},
	"/record/$id": {
		filePath: "/workspace/src/routes/record.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/record._id-BAagYv6z.js",
			"/assets/shelf-D5UEpQF1.js",
			"/assets/vinyl-BrU9ZyFL.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
