import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { familyOf, othersOfCharacter, resolveFigure, type Condition, type Figure, type Platform } from "@/data/catalog";
import { Badges, btnAmber, btnGhost, field, FigureLink, formatWhen, Gain, money } from "@/components/bits";
import { CompsChart } from "@/components/comps-chart";
import { VinylPlate, type PlateAngle } from "@/components/vinyl";
import { emptyHolding, useHydrated, useShelf, type Holding } from "@/lib/shelf";
import { summarize, quote } from "@/lib/value";

export const Route = createFileRoute("/record/$id")({ component: RecordPage });

const angles: { id: PlateAngle; label: string }[] = [
  { id: "front", label: "Front" },
  { id: "back", label: "Back" },
  { id: "side", label: "Side" },
  { id: "bottom", label: "Bottom" },
  { id: "sticker", label: "Sticker" },
  { id: "barcode", label: "Barcode" },
];

const conditions: Condition[] = ["Mint", "Near Mint", "Good", "Damaged"];

function RecordPage() {
  const { id } = Route.useParams();
  const custom = useShelf((s) => s.custom);
  const figure = resolveFigure(id, custom);
  const hydrated = useHydrated();
  if (!figure) {
    return (
      <div>
        <h1 className="font-display text-4xl">Not in the ledger</h1>
        <Link to="/catalog" search={{ q: "", lens: "all", family: "", series: "" }} className="mt-4 inline-flex min-h-11 items-center text-amber">
          Back to catalog
        </Link>
      </div>
    );
  }
  if (!hydrated) return <p className="text-mute">Opening the record…</p>;
  return <RecordBody key={id} figure={figure} />;
}

function RecordBody({ figure }: { figure: Figure }) {
  const holding = useShelf((s) => s.holdings.find((h) => h.recordId === figure.id));
  const want = useShelf((s) => s.wants.find((w) => w.recordId === figure.id));
  const upsert = useShelf((s) => s.upsertHolding);
  const remove = useShelf((s) => s.removeHolding);
  const upsertWant = useShelf((s) => s.upsertWant);
  const removeWant = useShelf((s) => s.removeWant);
  const logSale = useShelf((s) => s.logSale);
  const removeSale = useShelf((s) => s.removeSale);
  const custom = useShelf((s) => s.custom);
  const allSales = useShelf((s) => s.sales);
  const logged = allSales.filter((s) => s.recordId === figure.id);
  const [angle, setAngle] = useState<PlateAngle>("front");
  const [draft, setDraft] = useState<Holding>(holding ?? emptyHolding(figure.id));
  const [photoAngle, setPhotoAngle] = useState("Front");
  const [photoError, setPhotoError] = useState("");
  const [saved, setSaved] = useState("");
  const [salePrice, setSalePrice] = useState("");
  const [saleDate, setSaleDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [saleCondition, setSaleCondition] = useState<Condition>("Mint");
  const [salePlatform, setSalePlatform] = useState<Platform>("eBay");

  const family = useMemo(() => familyOf(figure, custom), [figure, custom]);
  const others = useMemo(() => othersOfCharacter(figure, custom), [figure, custom]);
  const market = quote(figure.sales, logged, draft.box);
  const chaseSibling = family.find((f) => f.isChase);

  function save(next: Holding) {
    if (next.photos.reduce((n, p) => n + p.dataUrl.length, 0) > 3_500_000) {
      setPhotoError("This shelf is full. Remove a photo first.");
      return;
    }
    upsert(next);
    setDraft(next);
    setSaved("Saved on this device.");
  }

  async function addPhoto(file: File) {
    setPhotoError("");
    try {
      const dataUrl = await shrink(file);
      const next = {
        ...draft,
        photos: [...draft.photos, { id: crypto.randomUUID(), angle: photoAngle, dataUrl }].slice(0, 6),
      };
      save(next);
    } catch (err) {
      setPhotoError(err instanceof Error ? err.message : "Couldn’t read that photo.");
    }
  }

  return (
    <div className="flex flex-col gap-8">
      <div>
        <Link to="/catalog" search={{ q: "", lens: "all", family: figure.familyId, series: "" }} className="text-sm text-amber">
          {figure.name} #{figure.number} · {family.length} known variants
        </Link>
        <h1 className="mt-2 font-display text-4xl sm:text-5xl">{figure.name}</h1>
        <p className="mt-2 text-lg text-dim">{figure.variant}</p>
        <div className="mt-3"><Badges figure={figure} /></div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <div>
          <VinylPlate figure={figure} angle={angle} large />
          <div className="mt-3 flex flex-wrap gap-2">
            {angles.map((a) => (
              <button
                key={a.id}
                type="button"
                className={`min-h-11 rounded-full px-3 text-sm ${angle === a.id ? "bg-amber text-amber-ink" : "border border-line text-paper"}`}
                onClick={() => setAngle(a.id)}
              >
                {a.label}
              </button>
            ))}
          </div>
          <p className="mt-2 text-sm text-mute">Paint plate, not a product photo. Your own photos sit on the shelf copy.</p>
        </div>

        <div className="rounded-2xl border border-line bg-panel p-4 sm:p-5">
          <h2 className="font-display text-2xl">Record</h2>
          <dl className="mt-3 grid grid-cols-1 gap-x-6 sm:grid-cols-2">
            <Fact k="Funko ID" v={figure.id} />
            <Fact k="Item number" v={figure.number} />
            <Fact k="Character" v={figure.character} />
            <Fact k="Series" v={figure.series} />
            <Fact k="Line" v={figure.line} />
            <Fact k="License" v={figure.license} />
            <Fact k="Release year" v={String(figure.year)} />
            <Fact k="Size" v={figure.size} />
            <Fact k="Country" v={figure.country} />
            <Fact k="Box style" v={figure.boxStyle ?? "—"} />
            <Fact k="Finish" v={figure.finish} />
            <Fact k="Production" v={figure.production} />
            <Fact k="Original retail" v={money(figure.msrp, true)} />
            <Fact k="UPC" v={figure.upc ?? "Not on file"} />
          </dl>
          <p className="mt-4 text-sm leading-relaxed text-dim">{figure.notes}</p>
        </div>
      </div>

      <section>
        <h2 className="font-display text-2xl">{figure.name} #{figure.number} — {family.length} known variants</h2>
        <ul className="mt-3 grid gap-2">
          {family.map((f) => (
            <li key={f.id}>
              <FigureLink
                figure={f}
                detail={(() => {
                  const rows = allSales.filter((s) => s.recordId === f.id);
                  return rows.length ? money(summarize(rows).estimate) : "Unpriced";
                })()}
              />
            </li>
          ))}
        </ul>
        {others.length > 0 && (
          <>
            <h3 className="mt-6 font-display text-xl">Other {figure.character} numbers</h3>
            <ul className="mt-3 grid gap-2">
              {others.map((f) => (
                <li key={f.id}><FigureLink figure={f} detail={`#${f.number}`} /></li>
              ))}
            </ul>
          </>
        )}
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-line bg-panel p-4">
          <h2 className="font-display text-2xl">Exclusive</h2>
          {figure.exclusiveKind === "none" ? (
            <p className="mt-2 text-dim">Common release. No retailer, convention, or shared sticker.</p>
          ) : (
            <dl className="mt-2">
              <Fact k="Type" v={figure.exclusiveKind} />
              <Fact k="Retailer" v={figure.retailer ?? "—"} />
              <Fact k="Convention" v={figure.convention ?? "None"} />
              <Fact k="Edition" v={figure.editionSize ? `${figure.editionSize.toLocaleString()} pieces` : "Not numbered"} />
              <Fact k="Sticker" v={figure.sticker ?? "—"} />
              <Fact k="Release" v={String(figure.year)} />
            </dl>
          )}
        </div>
        <div className="rounded-2xl border border-line bg-panel p-4">
          <h2 className="font-display text-2xl">Chase</h2>
          {figure.isChase ? (
            <>
              <p className="mt-2 text-dim">This is the chase of the family.</p>
              <p className="mt-2 text-amber">Chase ratio {figure.chaseRatio ?? "—"}</p>
            </>
          ) : chaseSibling ? (
            <p className="mt-2 text-dim">
              Standard of this number. Chase sibling:{" "}
              <Link to="/record/$id" params={{ id: chaseSibling.id }} className="text-amber">{chaseSibling.variant}</Link>
              {chaseSibling.chaseRatio ? ` · ${chaseSibling.chaseRatio}` : ""}.
            </p>
          ) : (
            <p className="mt-2 text-dim">No chase sibling in this family. Exclusives are tracked separately.</p>
          )}
          <label className="mt-4 flex min-h-11 items-center gap-3">
            <input
              type="checkbox"
              checked={draft.pulledChase}
              onChange={(e) => setDraft({ ...draft, pulledChase: e.target.checked })}
            />
            I pulled the chase myself
          </label>
        </div>
      </section>

      <section className="rounded-2xl border border-line bg-panel p-4 sm:p-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl">Value</h2>
            {market.source === "logged" ? (
              <>
                <p className="mt-1 text-sm text-mute">From {market.count} sales you logged</p>
                <p className="font-display text-5xl tabular-nums">{money(market.estimate)}</p>
              </>
            ) : (
              <>
                <p className="mt-1 text-sm text-mute">No verified price</p>
                <p className="font-display text-4xl">Log a sale</p>
              </>
            )}
          </div>
          <p className="text-sm text-dim">
            {market.source === "logged"
              ? `Your copy, ${draft.box} box: ${money(market.unit)}`
              : "Log a sale to price this copy"}
          </p>
        </div>
        {market.source === "logged" && (
          <div className="mt-4 grid grid-cols-3 gap-3">
            <Mini k="Low" v={money(market.low)} />
            <Mini k="Average" v={money(market.average)} />
            <Mini k="High" v={money(market.high)} />
          </div>
        )}
        <form
          className="mt-4 grid gap-3 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            const price = Number(salePrice);
            if (!Number.isFinite(price) || price <= 0) return;
            logSale({
              id: crypto.randomUUID(),
              recordId: figure.id,
              date: saleDate,
              price: Math.round(price),
              condition: saleCondition,
              platform: salePlatform,
            });
            setSalePrice("");
          }}
        >
          <label className="text-sm text-mute">
            Sale date
            <input className={`${field} mt-1`} type="date" value={saleDate} onChange={(e) => setSaleDate(e.target.value)} required />
          </label>
          <label className="text-sm text-mute">
            Price
            <input className={`${field} mt-1`} type="number" min={1} step={1} value={salePrice} onChange={(e) => setSalePrice(e.target.value)} placeholder="85" required />
          </label>
          <label className="text-sm text-mute">
            Condition
            <select className={`${field} mt-1`} value={saleCondition} onChange={(e) => setSaleCondition(e.target.value as Condition)}>
              {conditions.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          <label className="text-sm text-mute">
            Platform
            <select className={`${field} mt-1`} value={salePlatform} onChange={(e) => setSalePlatform(e.target.value as Platform)}>
              {(["eBay", "Whatnot", "Mercari", "Shop", "Other"] as const).map((p) => <option key={p}>{p}</option>)}
            </select>
          </label>
          <button type="submit" className={`${btnAmber} sm:col-span-2 sm:justify-self-start`}>Log this sale</button>
        </form>
        {logged.length > 0 && (
          <>
            <div className="mt-4"><CompsChart sales={logged} /></div>
            <SaleTable
              rows={logged}
              onRemove={(id) => removeSale(id)}
            />
          </>
        )}
      </section>

      <section className="rounded-2xl border border-line bg-panel p-4 sm:p-5">
        <h2 className="font-display text-2xl">Your copy</h2>
        <p className="mt-1 text-sm text-mute">Saved on this device. Not a shared account.</p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="text-sm text-mute">
            Quantity
            <input className={`${field} mt-1`} type="number" min={1} value={draft.qty}
              onChange={(e) => setDraft({ ...draft, qty: Math.max(1, Number(e.target.value) || 1) })} />
          </label>
          <label className="text-sm text-mute">
            Paid each
            <input className={`${field} mt-1`} type="number" min={0} value={draft.paid}
              onChange={(e) => setDraft({ ...draft, paid: Math.max(0, Number(e.target.value) || 0) })} />
          </label>
          <Choice label="Box" value={draft.box} onChange={(box) => setDraft({ ...draft, box })} />
          <Choice label="Figure" value={draft.figure} onChange={(fig) => setDraft({ ...draft, figure: fig })} />
          <label className="text-sm text-mute sm:col-span-2">
            Edition number on your copy
            <input className={`${field} mt-1`} value={draft.editionNumber} placeholder="128 / 480"
              onChange={(e) => setDraft({ ...draft, editionNumber: e.target.value })} />
          </label>
          <label className="text-sm text-mute sm:col-span-2">
            Collector notes
            <textarea className={`${field} mt-1 min-h-24 py-2`} value={draft.notes}
              onChange={(e) => setDraft({ ...draft, notes: e.target.value })} />
          </label>
        </div>
        <div className="mt-3 flex flex-wrap gap-4">
          <label className="flex min-h-11 items-center gap-2">
            <input type="checkbox" checked={draft.grail} onChange={(e) => setDraft({ ...draft, grail: e.target.checked })} />
            Grail
          </label>
          <label className="flex min-h-11 items-center gap-2">
            <input type="checkbox" checked={draft.forSale} onChange={(e) => setDraft({ ...draft, forSale: e.target.checked })} />
            For sale
          </label>
          {draft.forSale && (
            <label className="text-sm text-mute">
              Asking
              <input className={`${field} mt-1`} type="number" min={0} value={draft.ask ?? ""}
                onChange={(e) => setDraft({ ...draft, ask: e.target.value === "" ? null : Number(e.target.value) })} />
            </label>
          )}
        </div>

        <div className="mt-4 rounded-2xl border border-line p-3">
          <h3 className="font-display text-xl">Photos of your copy</h3>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <select className="min-h-11 rounded-xl border border-line bg-ink px-2" value={photoAngle} onChange={(e) => setPhotoAngle(e.target.value)}>
              {["Front", "Back", "Side", "Bottom", "Sticker", "Barcode", "Box damage", "Figure"].map((a) => (
                <option key={a}>{a}</option>
              ))}
            </select>
            <label className={`${btnGhost} cursor-pointer`}>
              Add photo
              <input
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  e.target.value = "";
                  if (file) void addPhoto(file);
                }}
              />
            </label>
          </div>
          {photoError && <p className="mt-2 text-sm text-dim">{photoError}</p>}
          {draft.photos.length > 0 && (
            <ul className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
              {draft.photos.map((photo) => (
                <li key={photo.id} className="overflow-hidden rounded-xl border border-line">
                  <img src={photo.dataUrl} alt={photo.angle} className="aspect-square w-full object-cover" />
                  <div className="flex items-center justify-between px-2 py-1">
                    <span className="text-sm text-mute">{photo.angle}</span>
                    <button
                      type="button"
                      className="min-h-11 px-2 text-sm text-amber"
                      onClick={() => setDraft({ ...draft, photos: draft.photos.filter((p) => p.id !== photo.id) })}
                    >
                      Remove
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <button type="button" className={btnAmber} onClick={() => save(draft)}>
            {holding ? "Update shelf" : "Add to shelf"}
          </button>
          <button
            type="button"
            className={btnGhost}
            onClick={() => {
              upsertWant(want ?? { recordId: figure.id, ceiling: null, note: "" });
              setSaved("On your want list.");
            }}
          >
            {want ? "On want list" : "Want list"}
          </button>
          {holding && (
            <button type="button" className={btnGhost} onClick={() => { remove(figure.id); setSaved("Removed from shelf."); }}>
              Remove
            </button>
          )}
          {want && (
            <button type="button" className={btnGhost} onClick={() => removeWant(figure.id)}>
              Drop want
            </button>
          )}
        </div>
        {saved && <p className="mt-3 text-sm text-amber">{saved}</p>}
        {holding && market.source === "logged" && (
          <p className="mt-3 text-sm text-dim">
            Line value {money(market.unit * holding.qty)} · in at {money(holding.paid * holding.qty)} ·{" "}
            <Gain n={market.unit * holding.qty - holding.paid * holding.qty} />
          </p>
        )}
      </section>
    </div>
  );
}

function Fact({ k, v }: { k: string; v: string }) {
  return (
    <div className="border-b border-line py-2">
      <dt className="text-sm text-mute">{k}</dt>
      <dd className="text-paper">{v}</dd>
    </div>
  );
}

function Mini({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <p className="text-sm text-mute">{k}</p>
      <p className="font-display text-2xl tabular-nums">{v}</p>
    </div>
  );
}

function Choice({ label, value, onChange }: { label: string; value: Condition; onChange: (c: Condition) => void }) {
  return (
    <fieldset>
      <legend className="text-sm text-mute">{label}</legend>
      <div className="mt-1 flex flex-wrap gap-2">
        {conditions.map((c) => (
          <button
            key={c}
            type="button"
            className={`min-h-11 rounded-full px-3 text-sm ${value === c ? "bg-amber text-amber-ink" : "border border-line"}`}
            onClick={() => onChange(c)}
          >
            {c}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

function SaleTable({ rows, onRemove }: { rows: { date: string; price: number; condition: string; platform: string; id?: string }[]; onRemove?: (id: string) => void }) {
  return (
    <div className="mt-4 overflow-x-auto">
      <table className="w-full min-w-[32rem] text-left text-sm">
        <thead className="text-mute">
          <tr>
            <th className="py-2 font-medium">Date</th>
            <th className="py-2 font-medium">Price</th>
            <th className="py-2 font-medium">Condition</th>
            <th className="py-2 font-medium">Platform</th>
            {onRemove && <th className="py-2 font-medium"> </th>}
          </tr>
        </thead>
        <tbody>
          {[...rows].sort((a, b) => b.date.localeCompare(a.date)).map((sale) => (
            <tr key={sale.id ?? `${sale.date}-${sale.price}-${sale.platform}`} className="border-t border-line">
              <td className="py-2 tabular-nums">{formatWhen(sale.date)}</td>
              <td className="py-2 tabular-nums">{money(sale.price)}</td>
              <td className="py-2">{sale.condition}</td>
              <td className="py-2">{sale.platform}</td>
              {onRemove && sale.id && (
                <td className="py-2">
                  <button type="button" className="min-h-11 text-amber" onClick={() => onRemove(sale.id!)}>Remove</button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

async function shrink(file: File) {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 720 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Couldn’t read that photo.");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  const url = canvas.toDataURL("image/jpeg", 0.72);
  if (url.length > 400_000) throw new Error("Still too large after shrinking.");
  return url;
}
