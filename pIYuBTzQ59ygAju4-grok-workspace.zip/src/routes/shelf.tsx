import { createFileRoute, Link } from "@tanstack/react-router";
import { getFigure, resolveFigure } from "@/data/catalog";
import { btnGhost, Gain, PageHeader, Stat } from "@/components/bits";
import { VinylPlate } from "@/components/vinyl";
import { shelfMath, useHydrated, useShelf, type Visibility } from "@/lib/shelf";
import { money, quote } from "@/lib/value";

export const Route = createFileRoute("/shelf")({ component: ShelfPage });

const vis: Visibility[] = ["private", "friends", "public"];

function ShelfPage() {
  const hydrated = useHydrated();
  const holdings = useShelf((s) => s.holdings);
  const custom = useShelf((s) => s.custom);
  const sales = useShelf((s) => s.sales);
  const visibility = useShelf((s) => s.visibility);
  const setVisibility = useShelf((s) => s.setVisibility);
  const resetSample = useShelf((s) => s.resetSample);
  const clearAll = useShelf((s) => s.clearAll);
  const math = shelfMath(holdings, custom, sales);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        kicker="Shelf"
        title="Your collection"
        lede="Paid is what you put in. Value counts only from sales you logged, adjusted for box condition. Sample illustrations are left out of the total."
      />
      {!hydrated ? (
        <p className="text-mute">Opening your shelf…</p>
      ) : (
        <>
          <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Verified value" value={money(math.verified)} hint={math.unpriced ? `${math.unpriced} copies have no logged sale` : `${math.copies} copies`} />
            <Stat label="Amount invested" value={money(math.invested)} />
            <Stat label="Gain on priced copies" value={math.gain >= 0 ? `+${money(math.gain)}` : `−${money(Math.abs(math.gain))}`} />
            <Stat label="Marks" value={`${math.chases} chase`} hint={`${math.grails} grail · ${math.exclusives} exclusive`} />
          </section>

          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-mute">Visibility, saved here only</p>
            {vis.map((v) => (
              <button
                key={v}
                type="button"
                className={`min-h-11 rounded-full px-4 capitalize ${visibility === v ? "bg-amber text-amber-ink" : "border border-line"}`}
                onClick={() => setVisibility(v)}
              >
                {v === "friends" ? "Friends only" : v}
              </button>
            ))}
          </div>
          <p className="text-sm text-mute">Sharing with other collectors waits on accounts. This choice stays on this device.</p>

          {holdings.length === 0 ? (
            <div className="rounded-2xl border border-line bg-panel px-4 py-8">
              <p className="text-dim">The shelf is empty.</p>
              <button type="button" className={`${btnGhost} mt-4`} onClick={resetSample}>Load the sample shelf</button>
            </div>
          ) : (
            <ul className="flex flex-col gap-3">
              {holdings.map((h) => {
                const figure = resolveFigure(h.recordId, custom) ?? getFigure(h.recordId);
                if (!figure) return null;
                const q = quote(figure.sales, sales.filter((s) => s.recordId === h.recordId), h.box);
                const invested = h.paid * h.qty;
                const line = q.source === "logged" ? q.unit * h.qty : null;
                return (
                  <li key={h.recordId} className="grid gap-3 rounded-2xl border border-line bg-panel p-3 sm:grid-cols-[140px_1fr]">
                    <VinylPlate figure={figure} />
                    <div>
                      <Link to="/record/$id" params={{ id: figure.id }} className="font-display text-2xl">
                        {figure.name}
                      </Link>
                      <p className="text-sm text-mute">#{figure.number} · {figure.variant} · qty {h.qty}</p>
                      <p className="mt-2 text-sm text-dim">{h.box} box · {h.figure} figure{h.grail ? " · Grail" : ""}{h.forSale ? ` · Asking ${money(h.ask ?? 0)}` : ""}</p>
                      <dl className="mt-3 grid grid-cols-3 gap-2 text-sm">
                        <div>
                          <dt className="text-mute">Paid</dt>
                          <dd className="tabular-nums">{money(invested)}</dd>
                        </div>
                        <div>
                          <dt className="text-mute">Value</dt>
                          <dd className="tabular-nums">{line == null ? "Unpriced" : money(line)}</dd>
                        </div>
                        <div>
                          <dt className="text-mute">Gain</dt>
                          <dd>{line == null ? "—" : <Gain n={line - invested} />}</dd>
                        </div>
                      </dl>
                      {h.notes && <p className="mt-2 text-sm text-dim">{h.notes}</p>}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}

          <div className="flex flex-wrap gap-2">
            <button type="button" className={btnGhost} onClick={resetSample}>Reset sample shelf</button>
            <button type="button" className={btnGhost} onClick={clearAll}>Clear shelf</button>
          </div>
        </>
      )}
    </div>
  );
}
