import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { getFigure, sets } from "@/data/catalog";
import { PageHeader } from "@/components/bits";
import { useShelf } from "@/lib/shelf";

export const Route = createFileRoute("/sets")({ component: SetsPage });

function SetsPage() {
  const holdings = useShelf((s) => s.holdings);
  const owned = useMemo(() => new Set(holdings.map((h) => h.recordId)), [holdings]);

  const totals = sets.reduce(
    (acc, set) => {
      acc.need += set.recordIds.length;
      acc.have += set.recordIds.filter((id) => owned.has(id)).length;
      return acc;
    },
    { have: 0, need: 0 },
  );
  const overall = totals.need ? Math.round((totals.have / totals.need) * 100) : 0;

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        kicker="Sets"
        title="Completion"
        lede="Each bar is a checklist in this ledger, not the entire real-world wave. Missing rows are figures we already know."
      />
      {holdings && (
        <p className="font-display text-3xl tabular-nums">
          {totals.have} / {totals.need} <span className="text-dim">tracked · {overall}%</span>
        </p>
      )}
      <ul className="flex flex-col gap-4">
        {sets.map((set) => {
          const have = set.recordIds.filter((id) => owned.has(id)).length;
          const pct = Math.round((have / set.recordIds.length) * 100);
          const missing = set.recordIds.filter((id) => !owned.has(id));
          return (
            <li key={set.id} className="rounded-2xl border border-line bg-panel p-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h2 className="font-display text-2xl">{set.name}</h2>
                <p className="tabular-nums text-dim">{have} / {set.recordIds.length} · {pct}%</p>
              </div>
              <p className="mt-1 text-sm text-mute">{set.blurb}</p>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-ink" aria-hidden>
                <div className="h-full rounded-full bg-amber" style={{ width: `${pct}%` }} />
              </div>
              {missing.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm text-mute">Missing</p>
                  <ul className="mt-2 flex flex-col gap-1">
                    {missing.map((id) => {
                      const figure = getFigure(id);
                      if (!figure) return null;
                      return (
                        <li key={id}>
                          <Link to="/record/$id" params={{ id }} className="inline-flex min-h-11 items-center text-paper">
                            {figure.name} #{figure.number}
                            <span className="ml-2 text-mute">{figure.variant}</span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
